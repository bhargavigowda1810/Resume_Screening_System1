'use client';

import{Component as s,withComponent as n}from"@primereact/core/component";import{mergeProps as d}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as m}from"@primereact/core/utils";var[k,t]=m();var o={as:"div"};var H=n({name:"DatePicker.Header",defaultProps:o,setup(){return{datepicker:t()}},render(e){let{props:a,ptmi:i,datepicker:r}=e,c=d(r?.headerProps,{className:r?.cx("header")},r?.ptm("header"),i("root"));return p.createElement(s,{instance:e,attrs:c,children:a.children})}});export{H as DatePickerHeader,o as defaultHeaderProps};
