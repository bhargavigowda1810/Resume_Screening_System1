'use client';

import{Component as m,withComponent as s}from"@primereact/core/component";import{mergeProps as P}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as c}from"@primereact/core/utils";var[k,r]=c();var o={as:"div"};var v=s({name:"DatePicker.Panel",defaultProps:o,setup(){return{datepicker:r()}},render(e){let{props:a,ptmi:i,datepicker:t}=e,n=P(t?.panelProps,{className:t?.cx("panel")},t?.ptm("panel"),i("root"));return p.createElement(m,{instance:e,attrs:n,children:a.children})}});export{v as DatePickerPanel,o as defaultPanelProps};
