'use client';

import{Component as m,withComponent as s}from"@primereact/core/component";import{mergeProps as u}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as c}from"@primereact/core/utils";var[k,e]=c();var o={as:"div"};var B=s({name:"DatePicker.Buttonbar",defaultProps:o,setup(){return{datepicker:e()}},render(t){let{props:a,ptmi:i,datepicker:r}=t,n=u(r?.buttonbarProps,{className:r?.cx("buttonbar")},r?.ptm("buttonbar"),i("root"));return p.createElement(m,{instance:t,attrs:n,children:a.children})}});export{B as DatePickerButtonbar,o as defaultButtonbarProps};
