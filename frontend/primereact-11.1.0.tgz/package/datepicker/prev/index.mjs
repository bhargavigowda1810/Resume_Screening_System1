'use client';

import{Component as m,withComponent as n}from"@primereact/core/component";import{mergeProps as P}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as s}from"@primereact/core/utils";var[k,t]=s();var o={as:"button"};var C=n({name:"DatePicker.Prev",defaultProps:o,setup(){return{datepicker:t()}},render(e){let{props:i,ptmi:c,datepicker:r}=e,a=P(r?.prevProps,{className:r?.cx("prev")},r?.ptm("prev"),c("root"));return p.createElement(m,{instance:e,attrs:a,children:i.children})}});export{C as DatePickerPrev,o as defaultPrevProps};
