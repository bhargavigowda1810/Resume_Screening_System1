'use client';

import{Component as s,withComponent as n}from"@primereact/core/component";import{mergeProps as d}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as m}from"@primereact/core/utils";var[k,r]=m();var o={as:"div"};var B=n({name:"DatePicker.Body",defaultProps:o,setup(){return{datepicker:r()}},render(e){let{props:i,ptmi:c,datepicker:t}=e,a=d(t?.bodyProps,{className:t?.cx("body")},t?.ptm("body"),c("root"));return p.createElement(s,{instance:e,attrs:a,children:i.children})}});export{B as DatePickerBody,o as defaultBodyProps};
