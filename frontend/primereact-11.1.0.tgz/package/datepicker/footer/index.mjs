'use client';

import{Component as s,withComponent as n}from"@primereact/core/component";import{mergeProps as P}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as m}from"@primereact/core/utils";var[k,r]=m();var o={as:"div"};var C=n({name:"DatePicker.Footer",defaultProps:o,setup(){return{datepicker:r()}},render(e){let{props:i,ptmi:c,datepicker:t}=e,a=P(t?.footerProps,t?.ptm("footer"),c("root"));return p.createElement(s,{instance:e,attrs:a,children:i.children})}});export{C as DatePickerFooter,o as defaultFooterProps};
