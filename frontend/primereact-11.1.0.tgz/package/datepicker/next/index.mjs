'use client';

import{Component as s,withComponent as m}from"@primereact/core/component";import{mergeProps as x}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as a}from"@primereact/core/utils";var[f,r]=a();var o={as:"button"};var C=m({name:"DatePicker.Next",defaultProps:o,setup(){return{datepicker:r()}},render(t){let{props:i,ptmi:c,datepicker:e}=t,n=x(e?.nextProps,{className:e?.cx("next")},e?.ptm("next"),c("root"));return p.createElement(s,{instance:t,attrs:n,children:i.children})}});export{C as DatePickerNext,o as defaultNextProps};
