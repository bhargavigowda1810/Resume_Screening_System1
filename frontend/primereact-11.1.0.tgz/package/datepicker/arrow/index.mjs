'use client';

import{Component as s,withComponent as n}from"@primereact/core/component";import{mergeProps as P}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as m}from"@primereact/core/utils";var[d,t]=m();var o={as:"div"};var A=n({name:"DatePicker.Arrow",defaultProps:o,setup(){return{datepicker:t()}},render(r){let{props:i,datepicker:e,ptmi:a}=r,c=P(e?.arrowProps,{className:e?.cx("arrow")},e?.ptm("arrow"),a("root"));return p.createElement(s,{instance:r,attrs:c,children:i.children})}});export{A as DatePickerArrow,o as defaultArrowProps};
