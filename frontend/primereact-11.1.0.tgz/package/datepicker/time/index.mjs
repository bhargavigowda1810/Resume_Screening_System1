'use client';

import{Component as s,withComponent as n}from"@primereact/core/component";import{mergeProps as P}from"@primeuix/utils";import*as i from"react";import{createOptionalContext as a}from"@primereact/core/utils";var[d,r]=a();var o={as:"div"};var C=n({name:"DatePicker.Time",defaultProps:o,setup(){return{datepicker:r()}},render(e){let{props:p,ptmi:m,datepicker:t}=e,c=P(t?.timePickerProps,{className:t?.cx("timePicker")},t?.ptm("timePicker"),m("root"));return i.createElement(s,{instance:e,attrs:c,children:p.children})}});export{C as DatePickerTime,o as defaultTimeProps};
