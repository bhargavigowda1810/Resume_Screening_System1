'use client';

import{Component as s,withComponent as n}from"@primereact/core/component";import{mergeProps as d}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as m}from"@primereact/core/utils";var[l,o]=m();var r={as:"tr"};var D=n({name:"DatePicker.TableBodyRow",defaultProps:r,setup(){return{datepicker:o()}},render(e){let{props:i,ptmi:a,datepicker:t}=e,c=d(t?.tableBodyRowProps,t?.ptm("tableBodyRow"),a("root"));return p.createElement(s,{instance:e,attrs:c,children:i.children})}});export{D as DatePickerTableBodyRow,r as defaultTableBodyRowProps};
