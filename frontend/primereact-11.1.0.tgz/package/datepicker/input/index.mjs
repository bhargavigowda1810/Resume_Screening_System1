'use client';

import{Component as m,withComponent as s}from"@primereact/core/component";import{mergeProps as u}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as a}from"@primereact/core/utils";var[k,r]=a();var o={as:"input"};var C=s({name:"DatePicker.Input",defaultProps:o,setup(){return{datepicker:r()}},render(t){let{props:i,ptmi:n,datepicker:e}=t,c=u(e?.inputProps,{className:e?.cx("input")},e?.ptm("input"),n("root"));return p.createElement(m,{instance:t,attrs:c,children:i.children})}});export{C as DatePickerInput,o as defaultInputProps};
