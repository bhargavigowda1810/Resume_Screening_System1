'use client';

import{Component as m,withComponent as s}from"@primereact/core/component";import{mergeProps as d}from"@primeuix/utils";import*as a from"react";import{createOptionalContext as n}from"@primereact/core/utils";var[P,t]=n();var o={as:"div"};var v=s({name:"DatePicker.Calendar",defaultProps:o,setup(){return{datepicker:t()}},render(e){let{props:p,ptmi:i,datepicker:r}=e,c=d(r?.calendarProps,{className:r?.cx("calendar")},r?.ptm("calendar"),i("root"));return a.createElement(m,{instance:e,attrs:c,children:p.children})}});export{v as DatePickerCalendar,o as defaultCalendarProps};
