'use client';

import{Component as i,withComponent as l}from"@primereact/core/component";import{mergeProps as a}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as n}from"@primereact/core/utils";var[u,o]=n();var r={as:"div"};var v=l({name:"Select.Footer",defaultProps:r,setup(){return{select:o()}},render(e){let{props:s,ptmi:c,select:t}=e,m=a({className:t?.cx("footer")},t?.ptm("footer"),c("root"));return p.createElement(i,{instance:e,attrs:m,children:s.children})}});export{v as SelectFooter,r as defaultFooterProps};
