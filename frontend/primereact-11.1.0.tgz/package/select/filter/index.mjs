'use client';

import{Component as m,withComponent as n}from"@primereact/core/component";import{mergeProps as a}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as l}from"@primereact/core/utils";var[u,r]=l();var o={as:"input"};var y=n({name:"Select.Filter",defaultProps:o,setup(){return{select:r()}},render(e){let{props:i,ptmi:s,select:t}=e,c=a(t?.filterProps,{className:t?.cx("filter")},t?.ptm("filter"),s("root"));return p.createElement(m,{instance:e,attrs:c,children:i.children})}});export{y as SelectFilter,o as defaultFilterProps};
