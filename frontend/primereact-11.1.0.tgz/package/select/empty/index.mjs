'use client';

import{Component as l,withComponent as a}from"@primereact/core/component";import{mergeProps as f}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as i}from"@primereact/core/utils";var[u,o]=i();var r={as:"span"};var h=a({name:"Select.Empty",defaultProps:r,setup(){return{select:o()}},render(t){let{props:m,ptmi:s,select:e}=t,{listbox:c}=e||{},n=f({className:e?.cx("empty")},e?.ptm("empty"),s("root"));return p.createElement(l,{pIf:c?.getOptions().length===0,instance:t,attrs:n,children:m.children})}});export{h as SelectEmpty,r as defaultEmptyProps};
