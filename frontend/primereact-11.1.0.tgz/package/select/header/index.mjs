'use client';

import{Component as i,withComponent as a}from"@primereact/core/component";import{mergeProps as l}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as n}from"@primereact/core/utils";var[f,r]=n();var o={as:"div"};var C=a({name:"Select.Header",defaultProps:o,setup(){return{select:r()}},render(e){let{props:s,ptmi:c,select:t}=e,m=l({className:t?.cx("header")},t?.ptm("header"),c("root"));return p.createElement(i,{instance:e,attrs:m,children:s.children})}});export{C as SelectHeader,o as defaultHeaderProps};
