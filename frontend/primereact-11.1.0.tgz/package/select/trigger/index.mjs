'use client';

import{Component as n,withComponent as l}from"@primereact/core/component";import{mergeProps as g}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as m}from"@primereact/core/utils";var[f,r]=m();var o={as:"button"};var C=l({name:"Select.Trigger",defaultProps:o,setup(){return{select:r()}},render(e){let{props:s,ptmi:i,select:t}=e,c=g(t?.triggerProps,{className:t?.cx("trigger")},t?.ptm("trigger"),i("root"));return p.createElement(n,{instance:e,attrs:c,children:s.children})}});export{C as SelectTrigger,o as defaultTriggerProps};
