'use client';

import{Component as i,withComponent as l}from"@primereact/core/component";import{mergeProps as a}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as n}from"@primereact/core/utils";var[u,t]=n();var o={as:"div"};var C=l({name:"Select.Arrow",defaultProps:o,setup(){return{select:t()}},render(e){let{props:s,select:r,ptmi:c}=e,m=a(r?.arrowProps,{className:r?.cx("arrow")},r?.ptm("arrow"),c("root"));return p.createElement(i,{instance:e,attrs:m,children:s.children})}});export{C as SelectArrow,o as defaultArrowProps};
