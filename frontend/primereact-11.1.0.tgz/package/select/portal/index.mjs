'use client';

import{withComponent as n}from"@primereact/core/component";import{mergeProps as a}from"@primeuix/utils";import{Portal as i}from"primereact/portal";import*as c from"react";import{createOptionalContext as m}from"@primereact/core/utils";var[f,r]=m();var p={};var v=n({name:"Select.Portal",defaultProps:p,setup(){return{select:r()}},render(t){let{props:e,ptmi:l,select:o}=t,s=a({className:o?.cx("portal")},o?.ptm("portal"),l("root"));return c.createElement(i,{instance:t,attrs:s,children:e.children,appendTo:e.appendTo})}});export{v as SelectPortal,p as defaultPortalProps};
