'use client';

import{Component as n,withComponent as a}from"@primereact/core/component";import{mergeProps as i}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as m}from"@primereact/core/utils";var[u,r]=m();var o={as:"span"};var y=a({name:"Select.Clear",defaultProps:o,setup(){return{select:r()}},render(t){let{props:s,ptmi:c,select:e}=t;if(!e?.hasValue())return null;let l=i(e?.clearProps,{className:e?.cx("clear")},e?.ptm("clear"),c("root"));return p.createElement(n,{instance:t,attrs:l,children:s.children})}});export{y as SelectClear,o as defaultClearProps};
