'use client';

import{Component as m,withComponent as c}from"@primereact/core/component";import{mergeProps as l}from"@primeuix/utils";import*as i from"react";import{createOptionalContext as n}from"@primereact/core/utils";var[g,e]=n();var r={as:"div"};var H=c({name:"Dialog.HeaderActions",defaultProps:r,setup(){return{dialog:e()}},render(o){let{props:a,ptmi:p,dialog:t}=o,s=l({className:t?.cx("headerActions")},t?.ptm("headerActions"),p("root"));return i.createElement(m,{instance:o,attrs:s,children:a.children})}});export{H as DialogHeaderActions,r as defaultHeaderActionsProps};
