'use client';

import{Component as n,withComponent as l}from"@primereact/core/component";import{mergeProps as c}from"@primeuix/utils";import*as i from"react";import{createOptionalContext as s}from"@primereact/core/utils";var[g,r]=s();var e={as:"div"};var C=l({name:"Dialog.Footer",defaultProps:e,setup(){return{dialog:r()}},render(o){let{props:p,ptmi:a,dialog:t}=o,m=c({className:t?.cx("footer")},t?.ptm("footer"),a("root"));return i.createElement(n,{instance:o,attrs:m,children:p.children})}});export{C as DialogFooter,e as defaultFooterProps};
