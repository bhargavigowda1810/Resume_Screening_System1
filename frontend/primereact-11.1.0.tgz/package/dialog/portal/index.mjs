'use client';

import{withComponent as n}from"@primereact/core/component";import{mergeProps as s}from"@primeuix/utils";import{Portal as c}from"primereact/portal";import*as p from"react";import{createOptionalContext as m}from"@primereact/core/utils";var[f,r]=m();var e={};var R=n({name:"Dialog.Portal",defaultProps:e,setup(){return{dialog:r()}},render(o){let{props:t,dialog:a,ptmi:i}=o,l=s(a?.ptm("portal"),i("root"));return p.createElement(c,{instance:o,attrs:l,children:t.children,appendTo:t.appendTo})}});export{R as DialogPortal,e as defaultPortalProps};
