'use client';

import{Component as s,withComponent as l}from"@primereact/core/component";import{mergeProps as c}from"@primeuix/utils";import*as n from"react";import{createOptionalContext as m}from"@primereact/core/utils";var[d,e]=m();var r={as:"div"};var v=l({name:"Dialog.Content",defaultProps:r,setup(){return{dialog:e()}},render(o){let{props:i,ptmi:p,dialog:t}=o,a=c(t?.contentProps,{className:t?.cx("content")},t?.ptm("content"),p("root"));return n.createElement(s,{instance:o,attrs:a,children:i.children})}});export{v as DialogContent,r as defaultContentProps};
