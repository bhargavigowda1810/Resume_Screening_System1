'use client';

import{Component as n,withComponent as d}from"@primereact/core/component";import{mergeProps as l}from"@primeuix/utils";import*as a from"react";import{createOptionalContext as s}from"@primereact/core/utils";var[g,r]=s();var t={as:"div"};var H=d({name:"Dialog.Header",defaultProps:t,setup(){return{dialog:r()}},render(o){let{props:i,ptmi:p,dialog:e}=o,m=l(e?.headerProps,{className:e?.cx("header")},e?.ptm("header"),p("root"));return a.createElement(n,{instance:o,attrs:m,children:i.children})}});export{H as DialogHeader,t as defaultHeaderProps};
