'use client';

import{Component as s,withComponent as n}from"@primereact/core/component";import{mergeProps as x}from"@primeuix/utils";import*as r from"react";import{createOptionalContext as l}from"@primereact/core/utils";var[g,i]=l();var e={as:"button"};var P=n({name:"Dialog.Maximizable",defaultProps:e,setup(){return{dialog:i()}},render(o){let{props:a,ptmi:m,dialog:t}=o,p=x(t?.maximizableProps,{className:t?.cx("maximizable")},t?.ptm("maximizable"),m("root"));return r.createElement(s,{instance:o,attrs:p,children:a.children})}});export{P as DialogMaximizable,e as defaultMaximizableProps};
