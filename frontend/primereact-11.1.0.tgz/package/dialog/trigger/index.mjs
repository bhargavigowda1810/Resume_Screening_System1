'use client';

import{Component as m,withComponent as n}from"@primereact/core/component";import{mergeProps as l}from"@primeuix/utils";import*as i from"react";import{createOptionalContext as s}from"@primereact/core/utils";var[f,t]=s();var e={as:"button"};var C=n({name:"Dialog.Trigger",defaultProps:e,setup(){return{dialog:t()}},render(o){let{props:p,ptmi:g,dialog:r}=o,a=l(r?.triggerProps,{className:r?.cx("trigger")},r?.ptm("trigger"),g("root"));return i.createElement(m,{instance:o,attrs:a,children:p.children})}});export{C as DialogTrigger,e as defaultTriggerProps};
