'use client';

import{Component as s,withComponent as n}from"@primereact/core/component";import{mergeProps as c}from"@primeuix/utils";import*as i from"react";import{createOptionalContext as m}from"@primereact/core/utils";var[d,e]=m();var r={as:"div"};var C=n({name:"Dialog.Title",defaultProps:r,setup(){return{dialog:e()}},render(t){let{props:p,ptmi:l,dialog:o}=t,a=c({className:o?.cx("title")},o?.ptm("title"),l("root"));return i.createElement(s,{instance:t,attrs:a,children:p.children})}});export{C as DialogTitle,r as defaultTitleProps};
