'use client';

import{Component as m,withComponent as n}from"@primereact/core/component";import{mergeProps as c}from"@primeuix/utils";import*as s from"react";import{createOptionalContext as a}from"@primereact/core/utils";var[f,e]=a();var r={as:"button"};var h=n({name:"Dialog.Close",defaultProps:r,setup(){return{dialog:e()}},render(o){let{props:i,ptmi:p,dialog:t}=o,l=c(t?.closeProps,{className:t?.cx("close")},t?.ptm("close"),p("root"));return s.createElement(m,{instance:o,attrs:l,children:i.children})}});export{h as DialogClose,r as defaultCloseProps};
