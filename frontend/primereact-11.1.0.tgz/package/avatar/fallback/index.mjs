'use client';

import{Component as c,withComponent as l}from"@primereact/core/component";import{mergeProps as i}from"@primeuix/utils";import*as e from"react";import{createOptionalContext as n}from"@primereact/core/utils";var[f,r]=n();var o={as:"span"};var P=l({name:"Avatar.Fallback",defaultProps:o,setup(){return{avatar:r()}},render(t){let{props:p,ptmi:s,avatar:a}=t,m=i({className:a?.cx("fallback")},a?.ptm("fallback"),s("root"));return e.createElement(c,{pIf:!a?.state.load,instance:t,attrs:m,children:p.children})}});export{P as AvatarFallback,o as defaultFallbackProps};
