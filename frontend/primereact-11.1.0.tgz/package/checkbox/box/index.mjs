'use client';

import{Component as n,withComponent as b}from"@primereact/core/component";import{mergeProps as h}from"@primeuix/utils";import*as c from"react";import{createOptionalContext as i}from"@primereact/core/utils";var[k,t]=i();var r={as:"div"};var B=b({name:"CheckboxBox",defaultProps:r,setup(){return{checkbox:t()}},render(o){let{id:p,props:x,ptmi:m,checkbox:e}=o,s=h(e?.boxProps,{id:p,className:e?.cx("box")},e?.ptm("box"),m("root"));return c.createElement(n,{instance:o,attrs:s,children:x.children})}});export{B as CheckboxBox,r as defaultBoxProps};
