'use client';

import{Component as m,withComponent as f}from"@primereact/core/component";import{mergeProps as i}from"@primeuix/utils";import*as a from"react";import{createOptionalContext as s}from"@primereact/core/utils";var[y,o]=s();var r={as:"button",onClick:void 0};var L=f({name:"Gallery.RotateLeft",defaultProps:r,setup(){return{gallery:o()}},render(t){let{props:l,ptmi:p,gallery:e}=t,n=i(e?.rotateLeftProps,{className:e?.cx("rotateLeft")},p("root"));return a.createElement(m,{instance:t,attrs:n,children:l.children})}});export{L as GalleryRotateLeft,r as defaultRotateLeftProps};
