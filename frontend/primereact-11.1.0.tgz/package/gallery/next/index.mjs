'use client';

import{Component as m,withComponent as i}from"@primereact/core/component";import{mergeProps as x}from"@primeuix/utils";import*as l from"react";import{createOptionalContext as s}from"@primereact/core/utils";var[f,t]=s();var o={as:"button"};var g=i({name:"Gallery.Next",defaultProps:o,setup(){return{gallery:t()}},render(e){let{props:p,ptmi:n,gallery:r}=e,a=x(r?.nextProps,{className:r?.cx("next")},n("root"));return l.createElement(m,{instance:e,attrs:a,children:p.children,ref:r?.nextRef})}});export{g as GalleryNext,o as defaultNextProps};
