'use client';

import{Component as n,withComponent as i}from"@primereact/core/component";import{mergeProps as c}from"@primeuix/utils";import*as a from"react";import{createOptionalContext as m}from"@primereact/core/utils";var[y,o]=m();var t={as:"div"};var g=i({name:"Gallery.Header",defaultProps:t,setup(){return{gallery:o()}},render(r){let{props:l,ptmi:p,gallery:e}=r,s=c(e?.headerProps,{className:e?.cx("header")},p("root"));return a.createElement(n,{instance:r,attrs:s,children:l.children})}});export{g as GalleryHeader,t as defaultHeaderProps};
