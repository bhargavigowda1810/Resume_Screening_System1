'use client';

import{Component as n,withComponent as i}from"@primereact/core/component";import{mergeProps as c}from"@primeuix/utils";import*as l from"react";import{createOptionalContext as m}from"@primereact/core/utils";var[y,e]=m();var t={as:"div"};var g=i({name:"Gallery.Footer",defaultProps:t,setup(){return{gallery:e()}},render(o){let{props:p,ptmi:a,gallery:r}=o,s=c(r?.footerProps,{className:r?.cx("footer")},a("root"));return l.createElement(n,{instance:o,attrs:s,children:p.children})}});export{g as GalleryFooter,t as defaultFooterProps};
