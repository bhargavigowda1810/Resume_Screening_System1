'use client';

import{Component as n,withComponent as c}from"@primereact/core/component";import{mergeProps as i}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as m}from"@primereact/core/utils";var[y,e]=m();var t={as:"div"};var B=c({name:"Gallery.Backdrop",defaultProps:t,setup(){return{gallery:e()}},render(r){let{props:a,ptmi:l,gallery:o}=r,s=i(o?.backdropProps,{className:o?.cx("backdrop")},l("root"));return p.createElement(n,{instance:r,attrs:s,children:a.children})}});export{B as GalleryBackdrop,t as defaultBackdropProps};
