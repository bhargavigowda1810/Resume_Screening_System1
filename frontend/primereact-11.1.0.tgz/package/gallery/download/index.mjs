'use client';

import{Component as m,withComponent as i}from"@primereact/core/component";import{mergeProps as d}from"@primeuix/utils";import*as l from"react";import{createOptionalContext as s}from"@primereact/core/utils";var[y,e]=s();var t={as:"button",onClick:void 0};var C=i({name:"Gallery.Download",defaultProps:t,setup(){return{gallery:e()}},render(o){let{props:n,ptmi:a,gallery:r}=o,p=d(r?.downloadProps,{className:r?.cx("download")},a("root"));return l.createElement(m,{instance:o,attrs:p,children:n.children})}});export{C as GalleryDownload,t as defaultDownloadProps};
