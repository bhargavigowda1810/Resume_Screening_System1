'use client';

import{Component as n,withComponent as i}from"@primereact/core/component";import{mergeProps as c}from"@primeuix/utils";import*as l from"react";import{createOptionalContext as m}from"@primereact/core/utils";var[f,e]=m();var t={as:"div"};var T=i({name:"Gallery.Toolbar",defaultProps:t,setup(){return{gallery:e()}},render(o){let{props:a,ptmi:p,gallery:r}=o,s=c(r?.toolbarProps,{className:r?.cx("toolbar")},p("root"));return l.createElement(n,{instance:o,attrs:s,children:a.children})}});export{T as GalleryToolbar,t as defaultToolbarProps};
