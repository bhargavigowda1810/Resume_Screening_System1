'use client';

import{Component as m,withComponent as i}from"@primereact/core/component";import{mergeProps as c}from"@primeuix/utils";import*as l from"react";import{createOptionalContext as n}from"@primereact/core/utils";var[y,o]=n();var t={as:"button"};var g=i({name:"Gallery.Prev",defaultProps:t,setup(){return{gallery:o()}},render(r){let{props:p,ptmi:a,gallery:e}=r,s=c(e?.prevProps,{className:e?.cx("prev")},a("root"));return l.createElement(m,{instance:r,attrs:s,children:p.children,ref:e?.prevRef})}});export{g as GalleryPrev,t as defaultPrevProps};
