'use client';

import{Component as s,withComponent as m}from"@primereact/core/component";import{mergeProps as c}from"@primeuix/utils";import*as l from"react";import{createOptionalContext as a}from"@primereact/core/utils";var[y,e]=a();var t={as:"button",onClick:void 0};var C=m({name:"Gallery.FlipX",defaultProps:t,setup(){return{gallery:e()}},render(r){let{props:p,ptmi:i,gallery:o}=r,n=c(o?.flipXProps,{className:o?.cx("flipX")},i("root"));return l.createElement(s,{instance:r,attrs:n,children:p.children})}});export{C as GalleryFlipX,t as defaultFlipXProps};
