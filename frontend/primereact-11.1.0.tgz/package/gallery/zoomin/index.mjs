'use client';

import{Component as s,withComponent as i}from"@primereact/core/component";import{mergeProps as c}from"@primeuix/utils";import*as n from"react";import{createOptionalContext as a}from"@primereact/core/utils";var[f,e]=a();var t={as:"button",onClick:void 0};var C=i({name:"Gallery.ZoomIn",defaultProps:t,setup(){return{gallery:e()}},render(o){let{props:l,ptmi:m,gallery:r}=o,p=c(r?.zoomInProps,{className:r?.cx("zoomIn")},m("root"));return n.createElement(s,{instance:o,attrs:p,children:l.children})}});export{C as GalleryZoomIn,t as defaultZoomInProps};
