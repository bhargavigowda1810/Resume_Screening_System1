'use client';

import{Component as s,withComponent as i}from"@primereact/core/component";import{mergeProps as u}from"@primeuix/utils";import*as l from"react";import{createOptionalContext as a}from"@primereact/core/utils";var[y,t]=a();var e={as:"button",onClick:void 0};var C=i({name:"Gallery.ZoomOut",defaultProps:e,setup(){return{gallery:t()}},render(o){let{props:m,ptmi:p,gallery:r}=o,n=u(r?.zoomOutProps,{className:r?.cx("zoomOut")},p("root"));return l.createElement(s,{instance:o,attrs:n,children:m.children})}});export{C as GalleryZoomOut,e as defaultZoomOutProps};
