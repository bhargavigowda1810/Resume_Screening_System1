'use client';

import{Component as s,withComponent as m}from"@primereact/core/component";import{mergeProps as c}from"@primeuix/utils";import*as a from"react";import{createOptionalContext as n}from"@primereact/core/utils";var[y,r]=n();var e={as:"button",onClick:void 0};var G=m({name:"Gallery.RotateRight",defaultProps:e,setup(){return{gallery:r()}},render(t){let{props:l,ptmi:p,gallery:o}=t,i=c(o?.rotateRightProps,{className:o?.cx("rotateRight")},p("root"));return a.createElement(s,{instance:t,attrs:i,children:l.children})}});export{G as GalleryRotateRight,e as defaultRotateRightProps};
