'use client';

import{Component as m,withComponent as i}from"@primereact/core/component";import{mergeProps as c}from"@primeuix/utils";import*as n from"react";import{createOptionalContext as s}from"@primereact/core/utils";var[f,r]=s();var e={as:"div"};var g=i({name:"Gallery.Content",defaultProps:e,setup(){return{gallery:r()}},render(t){let{props:l,ptmi:p,gallery:o}=t,a=c(o?.contentProps,{className:o?.cx("content")},p("root"));return n.createElement(m,{instance:t,attrs:a,children:l.children})}});export{g as GalleryContent,e as defaultContentProps};
