'use client';

import{Component as s,withComponent as i}from"@primereact/core/component";import{mergeProps as g}from"@primeuix/utils";import*as l from"react";import{createOptionalContext as a}from"@primereact/core/utils";var[y,r]=a();var t={as:"button",onClick:void 0};var T=i({name:"Gallery.ZoomToggle",defaultProps:t,setup(){return{gallery:r()}},render(o){let{props:m,ptmi:p,gallery:e}=o,n=g(e?.zoomToggleProps,{className:e?.cx("zoomToggle")},p("root"));return l.createElement(s,{instance:o,attrs:n,children:m.children})}});export{T as GalleryZoomToggle,t as defaultZoomToggleProps};
