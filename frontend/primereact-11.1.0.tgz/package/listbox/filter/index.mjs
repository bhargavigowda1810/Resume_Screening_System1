'use client';

import{Component as l,withComponent as x}from"@primereact/core/component";import{mergeProps as c}from"@primeuix/utils";import*as i from"react";import{createOptionalContext as n}from"@primereact/core/utils";var[b,r]=n();var e={as:"input"};var C=x({name:"Listbox.Filter",defaultProps:e,setup(){return{listbox:r()}},render(t){let{props:s,ptmi:p,listbox:o}=t,m=c(o?.filterProps,{className:o?.cx("pcFilter")},o?.ptm("pcFilter"),p("root"));return i.createElement(l,{instance:t,attrs:m,children:s.children})}});export{C as ListboxFilter,e as defaultFilterProps};
