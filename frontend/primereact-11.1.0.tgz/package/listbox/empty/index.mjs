'use client';

import{Component as x,withComponent as c}from"@primereact/core/component";import{mergeProps as a}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as n}from"@primereact/core/utils";var[b,r]=n();var e={as:"span"};var E=c({name:"Listbox.Empty",defaultProps:e,setup(){return{listbox:r()}},render(t){let{props:s,ptmi:i,listbox:o}=t,m=a({className:o?.cx("empty")},o?.ptm("empty"),i("root"));return p.createElement(x,{pIf:o?.getOptions().length===0,instance:t,attrs:m,children:s.children})}});export{E as ListboxEmpty,e as defaultEmptyProps};
