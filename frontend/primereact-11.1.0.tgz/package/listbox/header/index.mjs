'use client';

import{Component as a,withComponent as x}from"@primereact/core/component";import{mergeProps as c}from"@primeuix/utils";import*as s from"react";import{createOptionalContext as n}from"@primereact/core/utils";var[b,e]=n();var r={as:"div"};var h=x({name:"Listbox.Header",defaultProps:r,setup(){return{listbox:e()}},render(t){let{props:i,ptmi:p,listbox:o}=t,m=c({className:o?.cx("header")},o?.ptm("header"),p("root"));return s.createElement(a,{instance:t,attrs:m,children:i.children})}});export{h as ListboxHeader,r as defaultHeaderProps};
