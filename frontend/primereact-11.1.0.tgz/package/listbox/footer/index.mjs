'use client';

import{Component as x,withComponent as c}from"@primereact/core/component";import{mergeProps as a}from"@primeuix/utils";import*as s from"react";import{createOptionalContext as n}from"@primereact/core/utils";var[b,r]=n();var e={as:"div"};var C=c({name:"Listbox.Footer",defaultProps:e,setup(){return{listbox:r()}},render(o){let{props:i,ptmi:p,listbox:t}=o,m=a({className:t?.cx("footer")},t?.ptm("footer"),p("root"));return s.createElement(x,{instance:o,attrs:m,children:i.children})}});export{C as ListboxFooter,e as defaultFooterProps};
