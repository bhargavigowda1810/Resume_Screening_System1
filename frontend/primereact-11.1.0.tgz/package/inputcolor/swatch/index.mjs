'use client';

import{Component as m,withComponent as a}from"@primereact/core/component";import{mergeProps as u}from"@primeuix/utils";import*as e from"react";import{createOptionalContext as c}from"@primereact/core/utils";var[C,r]=c();var p={as:"div"};var d=a({name:"InputColor.Swatch",defaultProps:p,setup(){return{inputColor:r()}},render(o){let{props:n,ptmi:s,inputColor:t}=o,i=u(t?.swatchProps,{className:t?.cx("swatch")},t?.ptm("swatch"),s("root"));return e.createElement(m,{instance:o,attrs:i,children:n.children})}});export{d as InputColorSwatch,p as defaultSwatchProps};
