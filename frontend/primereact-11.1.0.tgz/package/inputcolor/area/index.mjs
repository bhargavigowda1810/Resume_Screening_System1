'use client';

import{Component as m,withComponent as l}from"@primereact/core/component";import{mergeProps as u}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as i}from"@primereact/core/utils";var[C,t]=i();var e={as:"div"};var A=l({name:"InputColor.Area",defaultProps:e,setup(){return{inputColor:t()}},render(r){let{props:n,ptmi:s,inputColor:o}=r,a=u(o?.areaProps,{className:o?.cx("area"),style:{...o?.areaProps?.style}},o?.ptm("area"),s("root"));return p.createElement(m,{instance:r,attrs:a,children:n.children})}});export{A as InputColorArea,e as defaultAreaProps};
