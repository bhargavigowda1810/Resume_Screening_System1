'use client';

import{Component as a,withComponent as d}from"@primereact/core/component";import{mergeProps as u}from"@primeuix/utils";import*as i from"react";import{createOptionalContext as m}from"@primereact/core/utils";var[b,o]=m();var t={as:"ul"};var C=d({name:"Sidebar.Menu",defaultProps:t,setup(){return{sidebar:o()}},render(e){let{props:p,ptmi:n,sidebar:r}=e,s=u(r?.menuProps,{className:r?.cx("menu")},r?.ptm("menu"),n("root"));return i.createElement(a,{instance:e,attrs:s,children:p.children})}});export{C as SidebarMenu,t as defaultMenuProps};
