'use client';

import{Component as m,withComponent as n}from"@primereact/core/component";import{mergeProps as d}from"@primeuix/utils";import*as i from"react";import{createOptionalContext as s}from"@primereact/core/utils";var[c,o]=s();var e={as:"button"};var S=n({name:"Sidebar.Rail",defaultProps:e,setup(){return{sidebar:o()}},render(r){let{ptmi:a,sidebar:t}=r,p=d(t?.railProps,{className:t?.cx("rail")},t?.ptm("rail"),a("root"));return i.createElement(m,{instance:r,attrs:p})}});export{S as SidebarRail,e as defaultRailProps};
