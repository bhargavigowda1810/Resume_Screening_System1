'use client';

import{Component as n,withComponent as d}from"@primereact/core/component";import{mergeProps as c}from"@primeuix/utils";import*as i from"react";import{createOptionalContext as m}from"@primereact/core/utils";var[b,t]=m();var e={as:"div"};var C=d({name:"Sidebar.Footer",defaultProps:e,setup(){return{sidebar:t()}},render(r){let{props:p,ptmi:s,sidebar:o}=r,a=c(o?.footerProps,{className:o?.cx("footer")},o?.ptm("footer"),s("root"));return i.createElement(n,{instance:r,attrs:a,children:p.children})}});export{C as SidebarFooter,e as defaultFooterProps};
