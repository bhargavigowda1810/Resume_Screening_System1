'use client';

import{Component as m,withComponent as d}from"@primereact/core/component";import{mergeProps as c}from"@primeuix/utils";import*as n from"react";import{createOptionalContext as a}from"@primereact/core/utils";var[f,o]=a();var r={as:"div"};var v=d({name:"Sidebar.Content",defaultProps:r,setup(){return{sidebar:o()}},render(t){let{props:i,ptmi:p,sidebar:e}=t,s=c(e?.contentProps,{className:e?.cx("content")},e?.ptm("content"),p("root"));return n.createElement(m,{instance:t,attrs:s,children:i.children})}});export{v as SidebarContent,r as defaultContentProps};
