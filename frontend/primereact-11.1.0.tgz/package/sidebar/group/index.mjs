'use client';

import{Component as n,withComponent as d}from"@primereact/core/component";import{mergeProps as u}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as m}from"@primereact/core/utils";var[b,t]=m();var e={as:"div"};var C=d({name:"Sidebar.Group",defaultProps:e,setup(){return{sidebar:t()}},render(r){let{props:i,ptmi:s,sidebar:o}=r,a=u(o?.groupProps,{className:o?.cx("group")},o?.ptm("group"),s("root"));return p.createElement(n,{instance:r,attrs:a,children:i.children})}});export{C as SidebarGroup,e as defaultGroupProps};
