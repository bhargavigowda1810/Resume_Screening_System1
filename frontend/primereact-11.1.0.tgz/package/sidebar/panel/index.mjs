'use client';

import{Component as m,withComponent as d}from"@primereact/core/component";import{mergeProps as l}from"@primeuix/utils";import*as a from"react";import{createOptionalContext as s}from"@primereact/core/utils";var[P,o]=s();var t={as:"div"};var v=d({name:"Sidebar.Panel",defaultProps:t,setup(){return{sidebar:o()}},render(e){let{props:p,ptmi:i,sidebar:r}=e,n=l(r?.panelProps,{className:r?.cx("panel")},r?.ptm("panel"),i("root"));return a.createElement(m,{instance:e,attrs:n,children:p.children})}});export{v as SidebarPanel,t as defaultPanelProps};
