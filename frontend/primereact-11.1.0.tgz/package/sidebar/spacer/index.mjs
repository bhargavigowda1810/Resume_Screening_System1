'use client';

import{Component as c,withComponent as n}from"@primereact/core/component";import{mergeProps as d}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as m}from"@primereact/core/utils";var[b,o]=m();var t={as:"div"};var v=n({name:"Sidebar.Spacer",defaultProps:t,setup(){return{sidebar:o()}},render(r){let{props:a,ptmi:i,sidebar:e}=r,s=d(e?.spacerProps,{className:e?.cx("spacer")},e?.ptm("spacer"),i("root"));return p.createElement(c,{instance:r,attrs:s,children:a.children})}});export{v as SidebarSpacer,t as defaultSpacerProps};
