'use client';

import{Component as m,withComponent as d}from"@primereact/core/component";import{mergeProps as u}from"@primeuix/utils";import*as n from"react";import{createOptionalContext as p}from"@primereact/core/utils";var[y,o]=p();var t={as:"main"};var g=d({name:"Sidebar.Main",defaultProps:t,setup(){return{layout:o()}},render(e){let{props:a,ptmi:i,layout:r}=e,s=u(r?.mainProps,{className:r?.cx("main")},r?.ptm("main"),i("root"));return n.createElement(m,{instance:e,attrs:s,children:a.children})}});export{g as SidebarMain,t as defaultMainProps};
