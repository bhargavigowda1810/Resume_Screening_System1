'use client';

import{Component as m,withComponent as c}from"@primereact/core/component";import{mergeProps as d}from"@primeuix/utils";import*as i from"react";import{createOptionalContext as a}from"@primereact/core/utils";var[b,t]=a();var e={as:"button"};var G=c({name:"Sidebar.GroupAction",defaultProps:e,setup(){return{sidebar:t()}},render(r){let{props:p,ptmi:n,sidebar:o}=r,s=d(o?.groupActionProps,{className:o?.cx("groupAction")},o?.ptm("groupAction"),n("root"));return i.createElement(m,{instance:r,attrs:s,children:p.children})}});export{G as SidebarGroupAction,e as defaultGroupActionProps};
