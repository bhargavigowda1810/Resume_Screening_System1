'use client';

import{Component as m,withComponent as n}from"@primereact/core/component";import{mergeProps as c}from"@primeuix/utils";import*as i from"react";import{createOptionalContext as d}from"@primereact/core/utils";var[f,o]=d();var t={as:"div"};var C=n({name:"Sidebar.Aside",defaultProps:t,setup(){return{sidebar:o()}},render(e){let{props:s,ptmi:p,sidebar:r}=e,a=c(r?.asideProps,{className:r?.cx("aside")},r?.ptm("aside"),p("root"));return i.createElement(m,{instance:e,attrs:a,children:s.children})}});export{C as SidebarAside,t as defaultAsideProps};
