'use client';

import{Component as n,withComponent as b}from"@primereact/core/component";import{mergeProps as d}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as m}from"@primereact/core/utils";var[u,t]=m();var o={as:"div"};var G=b({name:"Sidebar.GroupLabel",defaultProps:o,setup(){return{sidebar:t()}},render(r){let{props:a,ptmi:i,sidebar:e}=r,s=d(e?.groupLabelProps,{className:e?.cx("grouplabel")},e?.ptm("grouplabel"),i("root"));return p.createElement(n,{instance:r,attrs:s,children:a.children})}});export{G as SidebarGroupLabel,o as defaultGroupLabelProps};
