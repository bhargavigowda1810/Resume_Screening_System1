'use client';

import{Component as d,withComponent as m}from"@primereact/core/component";import{mergeProps as u}from"@primeuix/utils";import*as a from"react";import{createOptionalContext as s}from"@primereact/core/utils";var[b,o]=s();var t={as:"div"};var B=m({name:"Sidebar.MenuBadge",defaultProps:t,setup(){return{sidebar:o()}},render(e){let{props:i,ptmi:p,sidebar:r}=e,n=u(r?.menuBadgeProps,{className:r?.cx("menubadge")},r?.ptm("menubadge"),p("root"));return a.createElement(d,{instance:e,attrs:n,children:i.children})}});export{B as SidebarMenuBadge,t as defaultMenuBadgeProps};
