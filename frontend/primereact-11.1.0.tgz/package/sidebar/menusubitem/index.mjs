'use client';

import{Component as a,withComponent as u}from"@primereact/core/component";import{mergeProps as b}from"@primeuix/utils";import*as m from"react";import{createOptionalContext as n}from"@primereact/core/utils";var[c,o]=n();var t={as:"li"};var M=u({name:"Sidebar.MenuSubItem",defaultProps:t,setup(){return{sidebar:o()}},render(e){let{props:i,ptmi:p,sidebar:r}=e,s=b(r?.menuSubItemProps,{className:r?.cx("menusubitem")},r?.ptm("menusubitem"),p("root"));return m.createElement(a,{instance:e,attrs:s,children:i.children})}});export{M as SidebarMenuSubItem,t as defaultMenuSubItemProps};
