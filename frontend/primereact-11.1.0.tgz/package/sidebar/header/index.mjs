'use client';

import{Component as m,withComponent as n}from"@primereact/core/component";import{mergeProps as c}from"@primeuix/utils";import*as a from"react";import{createOptionalContext as d}from"@primereact/core/utils";var[f,o]=d();var t={as:"div"};var h=n({name:"Sidebar.Header",defaultProps:t,setup(){return{sidebar:o()}},render(e){let{props:i,ptmi:p,sidebar:r}=e,s=c(r?.headerProps,{className:r?.cx("header")},r?.ptm("header"),p("root"));return a.createElement(m,{instance:e,attrs:s,children:i.children})}});export{h as SidebarHeader,t as defaultHeaderProps};
