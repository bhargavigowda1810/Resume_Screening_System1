'use client';

import{Component as n,withComponent as b}from"@primereact/core/component";import{mergeProps as i}from"@primeuix/utils";import*as r from"react";import{createOptionalContext as s}from"@primereact/core/utils";var[T,a]=s();var o={as:"table"};var C=b({name:"DataTable.Table",defaultProps:o,setup(){return{datatable:a()}},render(t){let{props:p,ptmi:l,datatable:e}=t,m=i(e?.tableProps,{className:e?.cx("table")},e?.ptm("table"),l("root"));return r.createElement(n,{instance:t,attrs:m,children:p.children})}});export{C as DataTableTable,o as defaultTableProps};
