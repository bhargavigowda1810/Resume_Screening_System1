'use client';

import{Component as n,withComponent as l}from"@primereact/core/component";import{mergeProps as d}from"@primeuix/utils";import*as r from"react";import{createOptionalContext as i}from"@primereact/core/utils";var[T,a]=i();var o={as:"thead"};var h=l({name:"DataTable.THead",defaultProps:o,setup(){return{datatable:a()}},render(t){let{props:p,ptmi:s,datatable:e}=t,m=d({className:e?.cx("head"),style:{position:"sticky"}},e?.ptm("head"),s("root"));return r.createElement(n,{instance:t,attrs:m,children:p.children})}});export{h as DataTableTHead,o as defaultTHeadProps};
