'use client';

import{Component as m,withComponent as c}from"@primereact/core/component";import{mergeProps as d}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as a}from"@primereact/core/utils";var[f,t]=a();var r={as:"button"};var C=c({name:"SpeedDial.Action",defaultProps:r,setup(){return{speeddial:t()}},render(e){let{props:i,ptmi:n,speeddial:o}=e,s=d(o?.actionProps,{className:o?.cx("action")},o?.ptm("action"),n("root"));return p.createElement(m,{instance:e,attrs:s,children:i.children})}});export{C as SpeedDialAction,r as defaultActionProps};
