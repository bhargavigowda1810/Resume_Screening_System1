'use client';

import{Component as n,withComponent as l}from"@primereact/core/component";import{mergeProps as d}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as m}from"@primereact/core/utils";var[f,o]=m();var r={as:"ul"};var C=l({name:"SpeedDial.List",defaultProps:r,setup(){return{speeddial:o()}},render(e){let{props:i,ptmi:s,speeddial:t}=e,a=d(t?.listProps,{className:t?.cx("list")},s("root"));return p.createElement(n,{instance:e,attrs:a,children:i.children})}});export{C as SpeedDialList,r as defaultListProps};
