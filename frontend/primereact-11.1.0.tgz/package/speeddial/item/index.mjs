'use client';

import{Component as n,withComponent as d}from"@primereact/core/component";import{mergeProps as l}from"@primeuix/utils";import*as i from"react";import{createOptionalContext as a}from"@primereact/core/utils";var[f,r]=a();var p={as:"li",index:0};var C=d({name:"SpeedDial.Item",defaultProps:p,setup(){return{speeddial:r()}},render(e){let{props:t,ptmi:m,speeddial:o}=e,s=l(o?.getItemProps(t.index),{className:o?.cx("item")},m("root"));return i.createElement(n,{instance:e,attrs:s,children:t.children})}});export{C as SpeedDialItem,p as defaultItemProps};
