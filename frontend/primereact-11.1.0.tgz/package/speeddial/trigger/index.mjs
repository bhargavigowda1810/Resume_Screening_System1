'use client';

import{Component as n,withComponent as d}from"@primereact/core/component";import{mergeProps as l}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as m}from"@primereact/core/utils";var[c,t]=m();var o={as:"button"};var T=d({name:"SpeedDial.Trigger",defaultProps:o,setup(){return{speeddial:t()}},render(e){let{props:i,ptmi:s,speeddial:r}=e,a=l(r?.triggerProps,{className:r?.cx("trigger")},r?.ptm("trigger"),s("root"));return p.createElement(n,{instance:e,attrs:a,children:i.children})}});export{T as SpeedDialTrigger,o as defaultTriggerProps};
