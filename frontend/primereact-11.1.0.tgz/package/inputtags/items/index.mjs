'use client';

import{withComponent as i}from"@primereact/core/component";import*as t from"react";import{createOptionalContext as u}from"@primereact/core/utils";var[g,s]=u();var n={};var v=i({name:"InputTags.Items",defaultProps:n,setup(){return{inputtags:s()}},render(o){let{props:m,inputtags:e}=o;if(!e)return null;let a=m.children;return t.createElement(t.Fragment,null,e.state.value.map((p,r)=>t.createElement(t.Fragment,{key:`${p}_${r}`},a({item:p,index:r,remove:()=>e.removeItem(r),itemProps:e.getItemProps(r)}))))}});export{v as InputTagsItems,n as defaultItemsProps};
