'use client';

import{Component as i,withComponent as n}from"@primereact/core/component";import{mergeProps as u}from"@primeuix/utils";import*as m from"react";import{createOptionalContext as s}from"@primereact/core/utils";var[b,t]=s();var o={as:"li"};var C=n({name:"Breadcrumb.Item",defaultProps:o,setup(){return{breadcrumb:t()}},render(r){let{props:p,ptmi:c,breadcrumb:e}=r,a=u({className:e?.cx("item")},e?.ptm("item"),c("root"));return m.createElement(i,{instance:r,attrs:a,children:p.children})}});export{C as BreadcrumbItem,o as defaultItemProps};
