'use client';

import{Component as a,withComponent as s}from"@primereact/core/component";import{mergeProps as u}from"@primeuix/utils";import*as m from"react";import{createOptionalContext as i}from"@primereact/core/utils";var[b,t]=i();var o={as:"a"};var L=s({name:"Breadcrumb.Link",defaultProps:o,setup(){return{breadcrumb:t()}},render(r){let{props:p,ptmi:n,breadcrumb:e}=r,c=u({className:e?.cx("link")},e?.ptm("link"),n("root"));return m.createElement(a,{instance:r,attrs:c,children:p.children})}});export{L as BreadcrumbLink,o as defaultLinkProps};
