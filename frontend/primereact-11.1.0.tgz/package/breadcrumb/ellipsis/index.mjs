'use client';

import{Component as a,withComponent as l}from"@primereact/core/component";import{mergeProps as n}from"@primeuix/utils";import*as s from"react";import{createOptionalContext as c}from"@primereact/core/utils";var[d,t]=c();var o={as:"span"};var C=l({name:"Breadcrumb.Ellipsis",defaultProps:o,setup(){return{breadcrumb:t()}},render(r){let{props:p,ptmi:m,breadcrumb:e}=r,i=n(e?.ellipsisProps,{className:e?.cx("ellipsis")},e?.ptm("ellipsis"),m("root"));return s.createElement(a,{instance:r,attrs:i,children:p.children})}});export{C as BreadcrumbEllipsis,o as defaultEllipsisProps};
