'use client';

import{Component as a,withComponent as n}from"@primereact/core/component";import{mergeProps as u}from"@primeuix/utils";import*as m from"react";import{createOptionalContext as i}from"@primereact/core/utils";var[b,e]=i();var o={as:"ol"};var C=n({name:"Breadcrumb.List",defaultProps:o,setup(){return{breadcrumb:e()}},render(r){let{props:p,ptmi:s,breadcrumb:t}=r,c=u({className:t?.cx("list")},t?.ptm("list"),s("root"));return m.createElement(a,{instance:r,attrs:c,children:p.children})}});export{C as BreadcrumbList,o as defaultListProps};
