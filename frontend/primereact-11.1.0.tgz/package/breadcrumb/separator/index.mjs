'use client';

import{Component as n,withComponent as i}from"@primereact/core/component";import{mergeProps as u}from"@primeuix/utils";import*as a from"react";import{createOptionalContext as s}from"@primereact/core/utils";var[b,t]=s();var o={as:"li"};var C=i({name:"Breadcrumb.Separator",defaultProps:o,setup(){return{breadcrumb:t()}},render(r){let{props:p,ptmi:m,breadcrumb:e}=r,c=u(e?.separatorProps,{className:e?.cx("separator")},e?.ptm("separator"),m("root"));return a.createElement(n,{instance:r,attrs:c,children:p.children})}});export{C as BreadcrumbSeparator,o as defaultSeparatorProps};
