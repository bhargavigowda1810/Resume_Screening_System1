'use client';

import{Component as n,withComponent as g}from"@primereact/core/component";import{mergeProps as c}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as m}from"@primereact/core/utils";var[f,t]=m();var o={as:"button"};var T=g({name:"Drawer.Trigger",defaultProps:o,setup(){return{drawer:t()}},render(r){let{props:i,ptmi:a,drawer:e}=r,s=c(e?.triggerProps,{className:e?.cx("trigger")},e?.ptm("trigger"),a("root"));return p.createElement(n,{instance:r,attrs:s,children:i.children})}});export{T as DrawerTrigger,o as defaultTriggerProps};
