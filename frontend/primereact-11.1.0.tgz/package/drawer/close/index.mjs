'use client';

import{Component as c,withComponent as i}from"@primereact/core/component";import{mergeProps as l}from"@primeuix/utils";import*as s from"react";import{createOptionalContext as n}from"@primereact/core/utils";var[f,e]=n();var t={as:"button"};var h=i({name:"Drawer.Close",defaultProps:t,setup(){return{drawer:e()}},render(r){let{props:p,ptmi:a,drawer:o}=r,m=l(o?.closeProps,{className:o?.cx("close")},o?.ptm("close"),a("root"));return s.createElement(c,{instance:r,attrs:m,children:p.children})}});export{h as DrawerClose,t as defaultCloseProps};
