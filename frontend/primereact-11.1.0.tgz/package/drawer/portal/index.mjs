'use client';

import{withComponent as i}from"@primereact/core/component";import{mergeProps as l}from"@primeuix/utils";import{Portal as c}from"primereact/portal";import*as p from"react";import{createOptionalContext as s}from"@primereact/core/utils";var[f,t]=s();var e={};var R=i({name:"Drawer.Portal",defaultProps:e,setup(){return{drawer:t()}},render(r){let{props:o,drawer:a,ptmi:m}=r,n=l(a?.ptm("portal"),m("root"));return p.createElement(c,{instance:r,attrs:n,children:o.children,appendTo:o.appendTo})}});export{R as DrawerPortal,e as defaultPortalProps};
