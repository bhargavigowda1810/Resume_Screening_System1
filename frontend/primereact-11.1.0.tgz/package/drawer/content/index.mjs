'use client';

import{Component as i,withComponent as c}from"@primereact/core/component";import{mergeProps as w}from"@primeuix/utils";import*as n from"react";import{createOptionalContext as s}from"@primereact/core/utils";var[f,e]=s();var o={as:"div"};var v=c({name:"Drawer.Content",defaultProps:o,setup(){return{drawer:e()}},render(r){let{props:p,ptmi:a,drawer:t}=r,m=w({className:t?.cx("content")},t?.ptm("content"),a("root"));return n.createElement(i,{instance:r,attrs:m,children:p.children})}});export{v as DrawerContent,o as defaultContentProps};
