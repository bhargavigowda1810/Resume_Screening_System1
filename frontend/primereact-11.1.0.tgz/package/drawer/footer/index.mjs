'use client';

import{Component as i,withComponent as c}from"@primereact/core/component";import{mergeProps as f}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as n}from"@primereact/core/utils";var[d,e]=n();var t={as:"div"};var C=c({name:"Drawer.Footer",defaultProps:t,setup(){return{drawer:e()}},render(r){let{props:a,ptmi:m,drawer:o}=r,s=f({className:o?.cx("footer")},o?.ptm("footer"),m("root"));return p.createElement(i,{instance:r,attrs:s,children:a.children})}});export{C as DrawerFooter,t as defaultFooterProps};
