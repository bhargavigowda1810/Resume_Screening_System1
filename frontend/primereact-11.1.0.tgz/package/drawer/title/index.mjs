'use client';

import{Component as n,withComponent as c}from"@primereact/core/component";import{mergeProps as l}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as s}from"@primereact/core/utils";var[d,t]=s();var o={as:"div"};var C=c({name:"Drawer.Title",defaultProps:o,setup(){return{drawer:t()}},render(r){let{props:i,ptmi:a,drawer:e}=r,m=l({className:e?.cx("title")},e?.ptm("title"),a("root"));return p.createElement(n,{instance:r,attrs:m,children:i.children})}});export{C as DrawerTitle,o as defaultTitleProps};
