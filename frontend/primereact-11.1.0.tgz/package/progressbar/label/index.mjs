'use client';

import{Component as i,withComponent as l}from"@primereact/core/component";import{mergeProps as c}from"@primeuix/utils";import*as s from"react";import{createOptionalContext as n}from"@primereact/core/utils";var[g,o]=n();var t={as:"div"};var L=l({name:"ProgressBar.Label",defaultProps:t,setup(){return{progressbar:o()}},render(r){let{props:p,ptmi:a,progressbar:e}=r,m=c({className:e?.cx("label")},e?.ptm("label"),a("root"));return s.createElement(i,{instance:r,attrs:m,children:p.children})}});export{L as ProgressBarLabel,t as defaultLabelProps};
