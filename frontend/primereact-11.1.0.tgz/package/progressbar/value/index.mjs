'use client';

import{Component as m,withComponent as n}from"@primereact/core/component";import*as t from"react";import{createOptionalContext as p}from"@primereact/core/utils";var[u,e]=p();var o={as:"span"};var B=n({name:"ProgressBar.Value",defaultProps:o,setup(){return{progressbar:e()}},render(r){let{ptmi:s,progressbar:a}=r;return t.createElement(m,{instance:r,attrs:s("root"),children:a?.state.formattedValue})}});export{B as ProgressBarValue,o as defaultValueProps};
