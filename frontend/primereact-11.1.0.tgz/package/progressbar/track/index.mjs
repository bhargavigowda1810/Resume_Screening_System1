'use client';

import{Component as c,withComponent as i}from"@primereact/core/component";import{mergeProps as P}from"@primeuix/utils";import*as s from"react";import{createOptionalContext as n}from"@primereact/core/utils";var[f,e]=n();var t={as:"div"};var T=i({name:"ProgressBar.Track",defaultProps:t,setup(){return{progressbar:e()}},render(r){let{props:p,ptmi:a,progressbar:o}=r,m=P(o?.trackProps,{className:o?.cx("root")},o?.ptm("root"),a("root"));return s.createElement(c,{instance:r,attrs:m,children:p.children})}});export{T as ProgressBarTrack,t as defaultTrackProps};
