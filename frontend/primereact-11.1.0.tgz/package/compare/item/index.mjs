'use client';

import{Component as c,withComponent as f}from"@primereact/core/component";import{mergeProps as C}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as n}from"@primereact/core/utils";var[u,r]=n();var m={as:"div",position:"before"};var h=f({name:"Compare.Item",defaultProps:m,setup(){return{compare:r()}},render(e){let{props:t,ptmi:s,compare:o}=e,i=o?.getItemProps?.(t.position),a=C(i,{className:o?.cx("item")},o?.ptm("item"),s("root"));return p.createElement(c,{instance:e,attrs:a,children:t.children})}});export{h as CompareItem,m as defaultItemProps};
