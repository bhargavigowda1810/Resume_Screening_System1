'use client';

import{Component as i,withComponent as c}from"@primereact/core/component";import{mergeProps as d}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as s}from"@primereact/core/utils";var[C,r]=s();var t={as:"span"};var y=c({name:"Compare.Handle",defaultProps:t,setup(){return{compare:r()}},render(o){let{props:m,ptmi:a,compare:e}=o,n=d(e?.handleProps,{className:e?.cx("handle",{disabled:e?.props.disabled})},e?.ptm("handle"),a("root"));return p.createElement(i,{instance:o,attrs:n,children:m.children})}});export{y as CompareHandle,t as defaultHandleProps};
