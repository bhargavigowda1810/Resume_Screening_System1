'use client';

import{Component as c,withComponent as a}from"@primereact/core/component";import{mergeProps as h}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as n}from"@primereact/core/utils";var[f,t]=n();var r={as:"span"};var d=a({name:"Chip.Remove",defaultProps:r,setup(){return{chip:t()}},render(e){let{props:i,ptmi:m,chip:o}=e,s=h(o?.removeProps,{className:o?.cx("remove")},o?.ptm("remove"),m("root"));return p.createElement(c,{instance:e,attrs:s,children:i.children})}});export{d as ChipRemove,r as defaultRemoveProps};
