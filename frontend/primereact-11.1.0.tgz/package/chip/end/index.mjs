'use client';

import{Component as c,withComponent as h}from"@primereact/core/component";import{mergeProps as a}from"@primeuix/utils";import*as e from"react";import{createOptionalContext as s}from"@primereact/core/utils";var[C,r]=s();var p={as:"div"};var v=h({name:"Chip.End",defaultProps:p,setup(){return{chip:r()}},render(t){let{props:i,ptmi:n,chip:o}=t,m=a({className:o?.cx("end")},o?.ptm("end"),n("root"));return e.createElement(c,{instance:t,attrs:m,children:i.children})}});export{v as ChipEnd,p as defaultEndProps};
