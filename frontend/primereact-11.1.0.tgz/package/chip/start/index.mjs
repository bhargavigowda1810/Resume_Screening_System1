'use client';

import{Component as a,withComponent as c}from"@primereact/core/component";import{mergeProps as h}from"@primeuix/utils";import*as e from"react";import{createOptionalContext as n}from"@primereact/core/utils";var[f,o]=n();var p={as:"div"};var v=c({name:"Chip.Start",defaultProps:p,setup(){return{chip:o()}},render(t){let{props:i,ptmi:s,chip:r}=t,m=h({className:r?.cx("start")},r?.ptm("start"),s("root"));return e.createElement(a,{instance:t,attrs:m,children:i.children})}});export{v as ChipStart,p as defaultStartProps};
