'use client';

import{Component as a,withComponent as c}from"@primereact/core/component";import{mergeProps as l}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as n}from"@primereact/core/utils";var[C,o]=n();var r={as:"div"};var L=c({name:"Chip.Label",defaultProps:r,setup(){return{chip:o()}},render(t){let{props:i,ptmi:m,chip:e}=t,s=l({className:e?.cx("label")},e?.ptm("label"),m("root"));return p.createElement(a,{instance:t,attrs:s,children:i.children})}});export{L as ChipLabel,r as defaultLabelProps};
