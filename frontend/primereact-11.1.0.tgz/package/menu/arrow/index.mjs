'use client';

import{Component as u,withComponent as a}from"@primereact/core/component";import{mergeProps as c}from"@primeuix/utils";import*as n from"react";import{createOptionalContext as i}from"@primereact/core/utils";var[w,e]=i();var t={as:"div"};var C=a({name:"Menu.Arrow",defaultProps:t,setup(){return{menu:e()}},render(r){let{props:p,ptmi:m,menu:o}=r,s=c(o?.arrowProps,{className:o?.cx("arrow")},o?.ptm("arrow"),m("root"));return n.createElement(u,{instance:r,attrs:s,children:p.children})}});export{C as MenuArrow,t as defaultArrowProps};
