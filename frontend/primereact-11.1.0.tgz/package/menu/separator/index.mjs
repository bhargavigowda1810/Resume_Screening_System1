'use client';

import{Component as i,withComponent as u}from"@primereact/core/component";import{mergeProps as c}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as s}from"@primereact/core/utils";var[l,t]=s();var o={as:"div"};var v=u({name:"Menu.Separator",defaultProps:o,setup(){return{menu:t()}},render(r){let{props:n,ptmi:a,menu:e}=r,m=c(e?.separatorProps,{className:e?.cx("separator")},e?.ptm("separator"),a("root"));return p.createElement(i,{instance:r,attrs:m,children:n.children})}});export{v as MenuSeparator,o as defaultSeparatorProps};
