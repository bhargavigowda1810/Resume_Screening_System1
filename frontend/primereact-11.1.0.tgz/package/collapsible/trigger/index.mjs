'use client';

import{Component as m,withComponent as n}from"@primereact/core/component";import{mergeProps as c}from"@primeuix/utils";import*as l from"react";import{createOptionalContext as a}from"@primereact/core/utils";var[b,e]=a();var t={as:"button"};var T=n({name:"Collapsible.Trigger",defaultProps:t,setup(){return{collapsible:e()}},render(r){let{props:p,ptmi:i,collapsible:o}=r,s=c(o?.triggerProps,{className:o?.cx("trigger")},o?.ptm("trigger"),i("root"));return l.createElement(m,{instance:r,attrs:s,children:p.children})}});export{T as CollapsibleTrigger,t as defaultTriggerProps};
