'use client';

import{Component as a,withComponent as n}from"@primereact/core/component";import{mergeProps as l}from"@primeuix/utils";import*as i from"react";import{createOptionalContext as c}from"@primereact/core/utils";var[f,e]=c();var o={as:"div"};var y=n({name:"Slider.Track",defaultProps:o,setup(){return{slider:e()}},render(t){let{props:p,ptmi:s,slider:r}=t,m=l(r?.trackProps,{className:r?.cx("track"),style:r?.sx("track")},r?.ptm("track"),s("root"));return i.createElement(a,{instance:t,attrs:m,children:p.children})}});export{y as SliderTrack,o as defaultTrackProps};
