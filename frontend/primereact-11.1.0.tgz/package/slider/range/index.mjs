'use client';

import{Component as l,withComponent as d}from"@primereact/core/component";import{mergeProps as c}from"@primeuix/utils";import*as n from"react";import{createOptionalContext as a}from"@primereact/core/utils";var[g,t]=a();var o={as:"div"};var y=d({name:"Slider.Range",defaultProps:o,setup(){return{slider:t()}},render(r){let{props:i,ptmi:p,slider:e}=r,s=e?.getRangeProps?.(),m=c(s,{className:e?.cx("range"),style:e?.sx("range")},e?.ptm("range"),p("root"));return n.createElement(l,{instance:r,attrs:m,children:i.children})}});export{y as SliderRange,o as defaultContentProps};
