'use client';

import{Component as s,withComponent as m}from"@primereact/core/component";import{mergeProps as l}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as i}from"@primereact/core/utils";var[I,o]=i();var n={as:"div"};var y=m({name:"Inplace.Content",defaultProps:n,setup(){return{inplace:o()}},render(e){let{props:r,ptmi:c,inplace:t}=e,a=l(t?.contentProps,{className:t?.cx("content")},t?.ptm("content"),c("root"));return p.createElement(s,{pIf:t?.state.open,instance:e,attrs:a,children:r.children})}});export{y as InplaceContent,n as defaultContentProps};
