'use client';

import{Component as c,withComponent as l}from"@primereact/core/component";import{mergeProps as m}from"@primeuix/utils";import*as r from"react";import{createOptionalContext as s}from"@primereact/core/utils";var[y,t]=s();var o={as:"div"};var C=l({name:"Inplace.Display",defaultProps:o,setup(){return{inplace:t()}},render(p){let{props:n,ptmi:a,inplace:e}=p,i=m(e?.displayProps,{className:e?.cx("display")},e?.ptm("display"),a("root"));return r.createElement(c,{pIf:!e?.state.open,instance:p,attrs:i,children:n.children})}});export{C as InplaceDisplay,o as defaultDisplayProps};
