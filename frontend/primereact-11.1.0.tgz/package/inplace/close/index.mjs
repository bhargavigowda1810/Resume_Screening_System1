'use client';

import{Component as i,withComponent as a}from"@primereact/core/component";import{mergeProps as m}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as l}from"@primereact/core/utils";var[u,t]=l();var r={as:"button"};var h=a({name:"Inplace.Close",defaultProps:r,setup(){return{inplace:t()}},render(e){let{props:n,ptmi:s,inplace:o}=e,c=m(o?.closeProps,o?.ptm("close"),s("root"));return p.createElement(i,{instance:e,attrs:c,children:n.children})}});export{h as InplaceClose,r as defaultCloseProps};
