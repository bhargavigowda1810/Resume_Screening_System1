'use client';

import{Component as n,withComponent as c}from"@primereact/core/component";import{mergeProps as d}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as s}from"@primereact/core/utils";var[C,e]=s();var o={as:"div"};var y=c({name:"Card.Title",defaultProps:o,setup(){return{card:e()}},render(t){let{props:i,ptmi:a,card:r}=t,m=d({className:r?.cx("title")},r?.ptm("title"),a("root"));return p.createElement(n,{instance:t,attrs:m,children:i.children})}});export{y as CardTitle,o as defaultTitleProps};
