'use client';

import{Component as s,withComponent as c}from"@primereact/core/component";import{mergeProps as d}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as m}from"@primereact/core/utils";var[f,o]=m();var e={as:"div"};var h=c({name:"Card.Caption",defaultProps:e,setup(){return{card:o()}},render(r){let{props:a,ptmi:n,card:t}=r,i=d({className:t?.cx("caption")},t?.ptm("caption"),n("root"));return p.createElement(s,{instance:r,attrs:i,children:a.children})}});export{h as CardCaption,e as defaultCaptionProps};
