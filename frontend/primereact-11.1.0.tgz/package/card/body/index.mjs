'use client';

import{Component as n,withComponent as i}from"@primereact/core/component";import{mergeProps as c}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as s}from"@primereact/core/utils";var[f,t]=s();var e={as:"div"};var v=i({name:"Card.Body",defaultProps:e,setup(){return{card:t()}},render(r){let{props:a,ptmi:d,card:o}=r,m=c({className:o?.cx("body")},o?.ptm("body"),d("root"));return p.createElement(n,{instance:r,attrs:m,children:a.children})}});export{v as CardBody,e as defaultBodyProps};
