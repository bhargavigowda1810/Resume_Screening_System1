'use client';

import{Component as c,withComponent as i}from"@primereact/core/component";import{mergeProps as d}from"@primeuix/utils";import*as n from"react";import{createOptionalContext as s}from"@primereact/core/utils";var[f,o]=s();var e={as:"div"};var h=i({name:"Card.Content",defaultProps:e,setup(){return{card:o()}},render(t){let{props:p,ptmi:a,card:r}=t,m=d({className:r?.cx("content")},r?.ptm("content"),a("root"));return n.createElement(c,{instance:t,attrs:m,children:p.children})}});export{h as CardContent,e as defaultContentProps};
