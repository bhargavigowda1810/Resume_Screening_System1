'use client';

import{Component as n,withComponent as c}from"@primereact/core/component";import{mergeProps as d}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as m}from"@primereact/core/utils";var[l,e]=m();var o={as:"div"};var v=c({name:"Card.Subtitle",defaultProps:o,setup(){return{card:e()}},render(t){let{props:i,ptmi:a,card:r}=t,s=d({className:r?.cx("subtitle")},r?.ptm("subtitle"),a("root"));return p.createElement(n,{instance:t,attrs:s,children:i.children})}});export{v as CardSubtitle,o as defaultSubtitleProps};
