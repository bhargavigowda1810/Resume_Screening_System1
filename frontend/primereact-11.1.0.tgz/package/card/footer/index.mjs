'use client';

import{Component as i,withComponent as c}from"@primereact/core/component";import{mergeProps as d}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as n}from"@primereact/core/utils";var[C,t]=n();var e={as:"div"};var y=c({name:"Card.Footer",defaultProps:e,setup(){return{card:t()}},render(r){let{props:a,ptmi:m,card:o}=r,s=d({className:o?.cx("footer")},o?.ptm("footer"),m("root"));return p.createElement(i,{instance:r,attrs:s,children:a.children})}});export{y as CardFooter,e as defaultFooterProps};
