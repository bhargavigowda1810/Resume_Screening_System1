'use client';

import{Component as n,withComponent as i}from"@primereact/core/component";import{mergeProps as c}from"@primeuix/utils";import*as a from"react";import{createOptionalContext as s}from"@primereact/core/utils";var[f,t]=s();var o={as:"div"};var v=i({name:"Card.Header",defaultProps:o,setup(){return{card:t()}},render(r){let{props:p,ptmi:d,card:e}=r,m=c({className:e?.cx("header")},e?.ptm("header"),d("root"));return a.createElement(n,{instance:r,attrs:m,children:p.children})}});export{v as CardHeader,o as defaultHeaderProps};
