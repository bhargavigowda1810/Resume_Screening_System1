'use client';

import{Component as u,withComponent as d}from"@primereact/core/component";import{mergeProps as x}from"@primeuix/utils";import*as i from"react";import{createOptionalContext as s}from"@primereact/core/utils";var[B,r]=s();var e={as:"div"};var v=d({name:"RadioButton.Box",defaultProps:e,setup(){return{radiobutton:r()}},render(o){let{id:n,props:p,ptmi:a,radiobutton:t}=o,m=x(t?.boxProps,{id:n,className:t?.cx("box")},t?.ptm("box"),a("root"));return i.createElement(u,{instance:o,attrs:m,children:p.children})}});export{v as RadioButtonBox,e as defaultBoxProps};
