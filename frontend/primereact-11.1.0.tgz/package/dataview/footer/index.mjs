'use client';

import{Component as n,withComponent as c}from"@primereact/core/component";import{mergeProps as f}from"@primeuix/utils";import*as a from"react";import{createOptionalContext as s}from"@primereact/core/utils";var[d,e]=s();var r={as:"div"};var V=c({name:"DataView.Footer",defaultProps:r,setup(){return{dataview:e()}},render(t){let{props:i,ptmi:p,dataview:o}=t,m=f(o?.footerProps,{className:o?.cx("footer")},o?.ptm("footer"),p("root"));return a.createElement(n,{instance:t,attrs:m,children:i.children})}});export{V as DataViewFooter,r as defaultFooterProps};
