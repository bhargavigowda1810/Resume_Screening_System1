'use client';

import{Component as s,withComponent as c}from"@primereact/core/component";import{mergeProps as w}from"@primeuix/utils";import*as a from"react";import{createOptionalContext as m}from"@primereact/core/utils";var[f,o]=m();var r={as:"div"};var P=c({name:"DataView.Content",defaultProps:r,setup(){return{dataview:o()}},render(t){let{props:n,ptmi:i,dataview:e}=t,p=w(e?.contentProps,{className:e?.cx("content")},e?.ptm("content"),i("root"));return a.createElement(s,{instance:t,attrs:p,children:n.children})}});export{P as DataViewContent,r as defaultContentProps};
