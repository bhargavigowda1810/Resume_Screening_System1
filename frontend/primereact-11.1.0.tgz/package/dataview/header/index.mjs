'use client';

import{Component as n,withComponent as d}from"@primereact/core/component";import{mergeProps as c}from"@primeuix/utils";import*as a from"react";import{createOptionalContext as s}from"@primereact/core/utils";var[f,r]=s();var o={as:"div"};var V=d({name:"DataView.Header",defaultProps:o,setup(){return{dataview:r()}},render(e){let{props:i,ptmi:p,dataview:t}=e,m=c(t?.headerProps,{className:t?.cx("header")},t?.ptm("header"),p("root"));return a.createElement(n,{instance:e,attrs:m,children:i.children})}});export{V as DataViewHeader,o as defaultHeaderProps};
