'use client';

import{Component as n,withComponent as c}from"@primereact/core/component";import{mergeProps as w}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as s}from"@primereact/core/utils";var[f,o]=s();var r={as:"div"};var P=c({name:"DataView.Empty",defaultProps:r,setup(){return{dataview:o()}},render(t){let{props:a,ptmi:i,dataview:e}=t,m=w(e?.emptyProps,{className:e?.cx("empty")},e?.ptm("empty"),i("root"));return p.createElement(n,{instance:t,attrs:m,children:a.children})}});export{P as DataViewEmpty,r as defaultEmptyProps};
