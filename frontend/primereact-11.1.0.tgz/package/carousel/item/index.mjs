'use client';

import{Component as u,withComponent as l}from"@primereact/core/component";import{mergeProps as c}from"@primeuix/utils";import*as m from"react";import{createOptionalContext as n}from"@primereact/core/utils";var[C,t]=n();var s={as:"div",value:void 0};var h=l({name:"Carousel.Item",defaultProps:s,setup(){return{carousel:t()}},render(e){let{id:p,props:r,ptmi:a,carousel:o}=e,i=c(o?.getItemProps(r.value),{id:p,className:o?.cx("item")},o?.ptm("item"),a("root"));return m.createElement(u,{instance:e,attrs:i,children:r.children})}});export{h as CarouselItem,s as defaultItemProps};
