'use client';

import{Component as c,withComponent as i}from"@primereact/core/component";import{mergeProps as u}from"@primeuix/utils";import*as n from"react";import{createOptionalContext as m}from"@primereact/core/utils";var[C,e]=m();var r={as:"div"};var h=i({name:"Carousel.Content",defaultProps:r,setup(){return{carousel:e()}},render(o){let{props:s,ptmi:p,carousel:t}=o,a=u(t?.contentProps,{className:t?.cx("content")},t?.ptm("content"),p("root"));return n.createElement(c,{instance:o,attrs:a,children:s.children})}});export{h as CarouselContent,r as defaultContentProps};
