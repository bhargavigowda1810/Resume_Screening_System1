'use client';

import{withComponent as i}from"@primereact/core/component";import{mergeProps as P}from"@primeuix/utils";import{Portal as c}from"primereact/portal";import*as m from"react";import{createOptionalContext as s}from"@primereact/core/utils";var[v,e]=s();var p={};var R=i({name:"Popover.Portal",defaultProps:p,setup(){return{popover:e()}},render(o){let{props:r,popover:t,ptmi:n}=o,a=P({className:t?.cx("portal")},t?.ptm("portal"),n("root"));return m.createElement(c,{instance:o,attrs:a,children:r.children,appendTo:r.appendTo})}});export{R as PopoverPortal,p as defaultPortalProps};
