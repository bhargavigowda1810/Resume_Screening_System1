'use client';

import{Component as c,withComponent as l}from"@primereact/core/component";import{mergeProps as v}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as n}from"@primereact/core/utils";var[a,t]=n();var r={as:"h2"};var h=l({name:"Popover.Title",defaultProps:r,setup(){return{popover:t()}},render(o){let{props:i,ptmi:m,popover:e}=o,s=v({className:e?.cx("title")},e?.ptm("title"),m("root"));return p.createElement(c,{instance:o,attrs:s,children:i.children})}});export{h as PopoverTitle,r as defaultTitleProps};
