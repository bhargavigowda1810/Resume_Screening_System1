'use client';

import{Component as i,withComponent as l}from"@primereact/core/component";import{mergeProps as P}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as c}from"@primereact/core/utils";var[v,r]=c();var t={as:"button"};var R=l({name:"Popover.Close",defaultProps:t,setup(){return{popover:r()}},render(o){let{props:s,ptmi:m,popover:e}=o,n=P(e?.closeProps,{className:e?.cx("close")},e?.ptm("close"),m("root"));return p.createElement(i,{instance:o,attrs:n,children:s.children})}});export{R as PopoverClose,t as defaultCloseProps};
