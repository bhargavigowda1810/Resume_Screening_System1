'use client';

import{Component as c,withComponent as v}from"@primereact/core/component";import{mergeProps as P}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as i}from"@primereact/core/utils";var[f,e]=i();var r={as:"div"};var h=v({name:"Popover.Content",defaultProps:r,setup(){return{popover:e()}},render(o){let{props:n,ptmi:m,popover:t}=o,s=P({className:t?.cx("content")},t?.ptm("content"),m("root"));return p.createElement(c,{instance:o,attrs:s,children:n.children})}});export{h as PopoverContent,r as defaultContentProps};
