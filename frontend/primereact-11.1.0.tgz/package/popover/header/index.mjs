'use client';

import{Component as a,withComponent as c}from"@primereact/core/component";import{mergeProps as v}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as i}from"@primereact/core/utils";var[d,r]=i();var t={as:"div"};var C=c({name:"Popover.Header",defaultProps:t,setup(){return{popover:r()}},render(o){let{props:m,ptmi:s,popover:e}=o,n=v({className:e?.cx("header")},e?.ptm("header"),s("root"));return p.createElement(a,{instance:o,attrs:n,children:m.children})}});export{C as PopoverHeader,t as defaultHeaderProps};
