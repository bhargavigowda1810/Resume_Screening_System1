'use client';

import{Component as g,withComponent as c}from"@primereact/core/component";import{mergeProps as P}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as m}from"@primereact/core/utils";var[f,e]=m();var t={as:"button"};var C=c({name:"Popover.Trigger",defaultProps:t,setup(){return{popover:e()}},render(r){let{props:i,ptmi:s,popover:o}=r,n=P(o?.triggerProps,{className:o?.cx("trigger")},o?.ptm("trigger"),s("root"));return p.createElement(g,{instance:r,attrs:n,children:i.children,ref:o?.setAnchorRef})}});export{C as PopoverTrigger,t as defaultTriggerProps};
