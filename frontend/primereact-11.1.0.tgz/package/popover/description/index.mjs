'use client';

import{Component as c,withComponent as v}from"@primereact/core/component";import{mergeProps as P}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as m}from"@primereact/core/utils";var[f,e]=m();var t={as:"p"};var y=v({name:"Popover.Description",defaultProps:t,setup(){return{popover:e()}},render(o){let{props:i,ptmi:s,popover:r}=o,n=P({className:r?.cx("description")},r?.ptm("description"),s("root"));return p.createElement(c,{instance:o,attrs:n,children:i.children})}});export{y as PopoverDescription,t as defaultDescriptionProps};
