'use client';

import{Component as c,withComponent as v}from"@primereact/core/component";import{mergeProps as P}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as i}from"@primereact/core/utils";var[f,e]=i();var t={as:"div"};var y=v({name:"Popover.Footer",defaultProps:t,setup(){return{popover:e()}},render(o){let{props:m,ptmi:s,popover:r}=o,n=P({className:r?.cx("footer")},r?.ptm("footer"),s("root"));return p.createElement(c,{instance:o,attrs:n,children:m.children})}});export{y as PopoverFooter,t as defaultFooterProps};
