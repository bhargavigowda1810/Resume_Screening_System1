'use client';

import{Component as a,withComponent as c}from"@primereact/core/component";import{mergeProps as v}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as i}from"@primereact/core/utils";var[f,e]=i();var t={as:"div"};var C=c({name:"Popover.Arrow",defaultProps:t,setup(){return{popover:e()}},render(o){let{props:m,popover:r,ptmi:s}=o,n=v({className:r?.cx("arrow")},r?.ptm("arrow"),s("root"));return p.createElement(a,{instance:o,attrs:n,children:m.children,ref:r?.setArrowRef})}});export{C as PopoverArrow,t as defaultArrowProps};
