'use client';

import{Component as i,withComponent as c}from"@primereact/core/component";import{mergeProps as S}from"@primeuix/utils";import*as o from"react";import{createOptionalContext as n}from"@primereact/core/utils";var[u,t]=n();var p={as:"span"};var h=c({name:"Stepper.Separator",defaultProps:p,setup(){return{stepper:t()}},render(e){let{props:s,ptmi:a,stepper:r}=e,m=S({className:r?.cx("separator")},r?.ptm("separator"),a("root"));return o.createElement(i,{instance:e,attrs:m,children:s.children})}});export{h as StepperSeparator,p as defaultSeparatorProps};
