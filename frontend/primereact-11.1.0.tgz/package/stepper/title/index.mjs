'use client';

import{Component as c,withComponent as a}from"@primereact/core/component";import{mergeProps as l}from"@primeuix/utils";import*as o from"react";import{createOptionalContext as n}from"@primereact/core/utils";var[u,r]=n();var p={as:"span"};var y=a({name:"Stepper.Title",defaultProps:p,setup(){return{stepper:r()}},render(e){let{props:s,ptmi:i,stepper:t}=e,m=l({className:t?.cx("title")},t?.ptm("title"),i("root"));return o.createElement(c,{instance:e,attrs:m,children:s.children})}});export{y as StepperTitle,p as defaultTitleProps};
