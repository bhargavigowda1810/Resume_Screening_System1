'use client';

import{Component as c,withComponent as a}from"@primereact/core/component";import{mergeProps as f}from"@primeuix/utils";import*as o from"react";import{createOptionalContext as i}from"@primereact/core/utils";var[u,r]=i();var p={as:"div"};var y=a({name:"Stepper.Content",defaultProps:p,setup(){return{stepper:r()}},render(t){let{props:n,ptmi:s,stepper:e}=t,m=f({className:e?.cx("content")},e?.ptm("content"),s("root"));return o.createElement(c,{instance:t,attrs:m,children:n.children})}});export{y as StepperContent,p as defaultContentProps};
