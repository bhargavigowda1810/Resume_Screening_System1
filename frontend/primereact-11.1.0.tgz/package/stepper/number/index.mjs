'use client';

import{Component as c,withComponent as u}from"@primereact/core/component";import{mergeProps as a}from"@primeuix/utils";import*as o from"react";import{createOptionalContext as i}from"@primereact/core/utils";var[l,t]=i();var p={as:"span"};var C=u({name:"Stepper.Number",defaultProps:p,setup(){return{stepper:t()}},render(e){let{props:m,ptmi:s,stepper:r}=e,n=a({className:r?.cx("number")},r?.ptm("number"),s("root"));return o.createElement(c,{instance:e,attrs:n,children:m.children})}});export{C as StepperNumber,p as defaultNumberProps};
