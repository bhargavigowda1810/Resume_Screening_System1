'use client';

import{Component as a,withComponent as c}from"@primereact/core/component";import{mergeProps as l}from"@primeuix/utils";import*as o from"react";import{createOptionalContext as i}from"@primereact/core/utils";var[f,p]=i();var r={as:"div"};var y=c({name:"Stepper.Panels",defaultProps:r,setup(){return{stepper:p()}},render(e){let{props:s,ptmi:n,stepper:t}=e,m=l({className:t?.cx("panels")},t?.ptm("panels"),n("root"));return o.createElement(a,{instance:e,attrs:m,children:s.children})}});export{y as StepperPanels,r as defaultPanelsProps};
