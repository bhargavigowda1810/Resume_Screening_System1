'use client';

import{Component as c,withComponent as a}from"@primereact/core/component";import{mergeProps as f}from"@primeuix/utils";import*as o from"react";import{createOptionalContext as n}from"@primereact/core/utils";var[u,r]=n();var p={as:"div"};var v=a({name:"Stepper.List",defaultProps:p,setup(){return{stepper:r()}},render(t){let{props:s,ptmi:i,stepper:e}=t,m=f({className:e?.cx("list")},e?.ptm("list"),i("root"));return o.createElement(c,{instance:t,attrs:m,children:s.children})}});export{v as StepperList,p as defaultListProps};
