'use client';

import{Component as i,withComponent as c}from"@primereact/core/component";import{mergeProps as g}from"@primeuix/utils";import*as r from"react";import{createOptionalContext as a}from"@primereact/core/utils";var[u,t]=a();var s={as:"div"};var C=c({name:"Message.Icon",defaultProps:s,setup(){return{message:t()}},render(e){let{props:p,ptmi:m,message:o}=e,n=g({className:o?.cx("icon")},o?.ptm("icon"),m("root"));return r.createElement(i,{instance:e,attrs:n,children:p.children})}});export{C as MessageIcon,s as defaultIconProps};
