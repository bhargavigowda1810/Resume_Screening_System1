'use client';

import{Component as i,withComponent as c}from"@primereact/core/component";import{mergeProps as g}from"@primeuix/utils";import*as r from"react";import{createOptionalContext as a}from"@primereact/core/utils";var[C,o]=a();var s={as:"div"};var v=c({name:"Message.Content",defaultProps:s,setup(){return{message:o()}},render(e){let{props:n,ptmi:p,message:t}=e,m=g({className:t?.cx("content")},t?.ptm("content"),p("root"));return r.createElement(i,{instance:e,attrs:m,children:n.children})}});export{v as MessageContent,s as defaultContentProps};
