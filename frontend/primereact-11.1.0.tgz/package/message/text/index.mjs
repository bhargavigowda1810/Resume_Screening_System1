'use client';

import{Component as i,withComponent as c}from"@primereact/core/component";import{mergeProps as x}from"@primeuix/utils";import*as r from"react";import{createOptionalContext as n}from"@primereact/core/utils";var[f,s]=n();var o={as:"p"};var C=c({name:"Message.Text",defaultProps:o,setup(){return{message:s()}},render(e){let{props:p,ptmi:m,message:t}=e,a=x({className:t?.cx("text")},t?.ptm("text"),m("root"));return r.createElement(i,{instance:e,attrs:a,children:p.children})}});export{C as MessageText,o as defaultTextProps};
