'use client';

import{Component as m,withComponent as s}from"@primereact/core/component";import{mergeProps as c}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as a}from"@primereact/core/utils";var[f,o]=a();var r={as:"div"};var y=s({name:"Panel.Title",defaultProps:r,setup(){return{panel:o()}},render(e){let{props:n,ptmi:i,panel:t}=e,l=c({className:t?.cx("title")},t?.ptm("title"),i("root"));return p.createElement(m,{instance:e,attrs:l,children:n.children})}});export{y as PanelTitle,r as defaultTitleProps};
