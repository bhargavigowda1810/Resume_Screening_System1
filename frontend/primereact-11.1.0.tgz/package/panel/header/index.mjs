'use client';

import{Component as i,withComponent as l}from"@primereact/core/component";import{mergeProps as c}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as s}from"@primereact/core/utils";var[d,t]=s();var o={as:"div"};var v=l({name:"Panel.Header",defaultProps:o,setup(){return{panel:t()}},render(e){let{props:n,ptmi:a,panel:r}=e,m=c({className:r?.cx("header")},r?.ptm("header"),a("root"));return p.createElement(i,{instance:e,attrs:m,children:n.children})}});export{v as PanelHeader,o as defaultHeaderProps};
