'use client';

import{Component as i,withComponent as l}from"@primereact/core/component";import{mergeProps as c}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as s}from"@primereact/core/utils";var[f,t]=s();var r={as:"div"};var y=l({name:"Panel.Footer",defaultProps:r,setup(){return{panel:t()}},render(o){let{props:n,ptmi:a,panel:e}=o,m=c({className:e?.cx("footer")},e?.ptm("footer"),a("root"));return p.createElement(i,{instance:o,attrs:m,children:n.children})}});export{y as PanelFooter,r as defaultFooterProps};
