'use client';

import{Component as s,withComponent as l}from"@primereact/core/component";import{mergeProps as g}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as m}from"@primereact/core/utils";var[P,t]=m();var o={as:"button"};var y=l({name:"Panel.Trigger",defaultProps:o,setup(){return{panel:t()}},render(r){let{props:n,ptmi:i,panel:e}=r,a=g(e?.triggerProps,{className:e?.cx("trigger")},e?.ptm("trigger"),i("root"));return p.createElement(s,{instance:r,attrs:a,children:n.children})}});export{y as PanelTrigger,o as defaultTriggerProps};
