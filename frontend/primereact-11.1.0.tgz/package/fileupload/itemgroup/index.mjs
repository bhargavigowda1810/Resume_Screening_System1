'use client';

import{Component as a,withComponent as n}from"@primereact/core/component";import{mergeProps as d}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as s}from"@primereact/core/utils";var[u,t]=s();var r={as:"div"};var G=n({name:"FileUpload.ItemGroup",defaultProps:r,setup(){return{fileupload:t()}},render(o){let{props:i,ptmi:l,fileupload:e}=o,m=d(e?.fileListProps,{className:e?.cx("fileList")},e?.ptm("fileList"),l("root"));return p.createElement(a,{instance:o,attrs:m,children:i.children})}});export{G as FileUploadItemGroup,r as defaultItemGroupProps};
