'use client';

import{Component as m,withComponent as n}from"@primereact/core/component";import{mergeProps as s}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as d}from"@primereact/core/utils";var[u,e]=d();var t={as:"button"};var y=n({name:"FileUpload.Upload",defaultProps:t,setup(){return{fileupload:e()}},render(o){let{props:r,ptmi:l,fileupload:i}=o,a=s(i?.uploadProps,l("root"));return p.createElement(m,{instance:o,attrs:a,children:r.children})}});export{y as FileUploadUpload,t as defaultUploadProps};
