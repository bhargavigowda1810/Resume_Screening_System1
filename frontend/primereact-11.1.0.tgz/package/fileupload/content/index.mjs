'use client';

import{Component as m,withComponent as s}from"@primereact/core/component";import{mergeProps as d}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as a}from"@primereact/core/utils";var[f,e]=a();var r={as:"div"};var v=s({name:"FileUpload.Content",defaultProps:r,setup(){return{fileupload:e()}},render(o){let{props:n,ptmi:i,fileupload:t}=o,l=d(t?.contentProps,{className:t?.cx("content")},t?.ptm("content"),i("root"));return p.createElement(m,{instance:o,attrs:l,children:n.children})}});export{v as FileUploadContent,r as defaultContentProps};
