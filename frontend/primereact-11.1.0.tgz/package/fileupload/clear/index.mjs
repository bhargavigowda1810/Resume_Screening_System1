'use client';

import{Component as n,withComponent as s}from"@primereact/core/component";import{mergeProps as d}from"@primeuix/utils";import*as t from"react";import{createOptionalContext as m}from"@primereact/core/utils";var[c,e]=m();var r={as:"button"};var y=s({name:"FileUpload.Clear",defaultProps:r,setup(){return{fileupload:e()}},render(o){let{props:p,ptmi:l,fileupload:i}=o,a=d(i?.clearProps,l("root"));return t.createElement(n,{instance:o,attrs:a,children:p.children})}});export{y as FileUploadClear,r as defaultClearProps};
