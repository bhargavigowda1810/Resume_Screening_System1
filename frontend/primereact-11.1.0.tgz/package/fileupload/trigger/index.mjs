'use client';

import{Component as m,withComponent as n}from"@primereact/core/component";import{mergeProps as d}from"@primeuix/utils";import*as t from"react";import{createOptionalContext as s}from"@primereact/core/utils";var[c,e]=s();var r={as:"button"};var T=n({name:"FileUpload.Trigger",defaultProps:r,setup(){return{fileupload:e()}},render(o){let{props:p,ptmi:i,fileupload:l}=o,a=d(l?.chooseProps,i("root"));return t.createElement(m,{instance:o,attrs:a,children:p.children})}});export{T as FileUploadTrigger,r as defaultTriggerProps};
