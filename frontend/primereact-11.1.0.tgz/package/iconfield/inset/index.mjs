'use client';

import{Component as m,withComponent as l}from"@primereact/core/component";import{mergeProps as d}from"@primeuix/utils";import*as n from"react";import{createOptionalContext as c}from"@primereact/core/utils";var[a,t]=c();var r={as:"span"};var y=l({name:"IconField.Inset",defaultProps:r,setup(){return{iconfield:t()}},render(e){let{props:i,ptmi:p,iconfield:o}=e,s=d({className:o?.cx("inset")},o?.ptm("inset"),p("root"));return n.createElement(m,{instance:e,attrs:s,children:i.children})}});export{y as IconFieldInset,r as defaultInsetProps};
