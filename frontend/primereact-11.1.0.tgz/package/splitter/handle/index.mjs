'use client';

import{Component as a,withComponent as c}from"@primereact/core/component";import{mergeProps as d}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as m}from"@primereact/core/utils";var[u,r]=m();var o={as:"div"};var v=c({name:"Splitter.Handle",defaultProps:o,setup(){return{splitter:r()}},render(t){let{id:i,props:n,ptmi:s,splitter:e}=t,l=d(e?.handleProps,{id:i,className:e?.cx("handle")},e?.ptm("handle"),s("root"));return p.createElement(a,{instance:t,attrs:l,children:n.children})}});export{v as SplitterHandle,o as defaultHandleProps};
