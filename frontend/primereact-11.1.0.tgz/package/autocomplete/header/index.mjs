'use client';

import{Component as i,withComponent as u}from"@primereact/core/component";import{mergeProps as c}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as n}from"@primereact/core/utils";var[d,o]=n();var r={as:"div"};var h=u({name:"AutoComplete.Header",defaultProps:r,setup(){return{autocomplete:o()}},render(e){let{props:m,ptmi:a,autocomplete:t}=e,s=c({className:t?.cx("header")},t?.ptm("header"),a("root"));return p.createElement(i,{instance:e,attrs:s,children:m.children})}});export{h as AutoCompleteHeader,r as defaultHeaderProps};
