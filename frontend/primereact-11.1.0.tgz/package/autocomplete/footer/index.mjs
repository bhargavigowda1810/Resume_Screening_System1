'use client';

import{Component as u,withComponent as c}from"@primereact/core/component";import{mergeProps as l}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as i}from"@primereact/core/utils";var[f,e]=i();var r={as:"div"};var v=c({name:"AutoComplete.Footer",defaultProps:r,setup(){return{autocomplete:e()}},render(o){let{props:m,ptmi:s,autocomplete:t}=o,n=l({className:t?.cx("footer")},t?.ptm("footer"),s("root"));return p.createElement(u,{instance:o,attrs:n,children:m.children})}});export{v as AutoCompleteFooter,r as defaultFooterProps};
