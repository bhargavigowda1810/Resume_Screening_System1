'use client';

import{Component as i,withComponent as c}from"@primereact/core/component";import{mergeProps as l}from"@primeuix/utils";import*as r from"react";import{createOptionalContext as s}from"@primereact/core/utils";var[C,e]=s();var p={as:"input"};var y=c({name:"AutoComplete.Input",defaultProps:p,setup(){return{autocomplete:e()}},render(t){let{props:m,ptmi:n,autocomplete:o}=t,u=l(o?.inputProps,{className:o?.cx("input")},o?.ptm("input"),n("root"));return r.createElement(i,{instance:t,attrs:u,children:m.children})}});export{y as AutoCompleteInput,p as defaultInputProps};
