'use client';

import{Component as a,withComponent as c}from"@primereact/core/component";import{mergeProps as u}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as i}from"@primereact/core/utils";var[A,e]=i();var r={as:"div"};var v=c({name:"AutoComplete.Arrow",defaultProps:r,setup(){return{autocomplete:e()}},render(o){let{props:m,autocomplete:t,ptmi:s}=o,n=u(t?.arrowProps,{className:t?.cx("arrow")},t?.ptm("arrow"),s("root"));return p.createElement(a,{instance:o,attrs:n,children:m.children})}});export{v as AutoCompleteArrow,r as defaultArrowProps};
