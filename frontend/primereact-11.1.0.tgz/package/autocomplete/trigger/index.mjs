'use client';

import{Component as u,withComponent as c}from"@primereact/core/component";import{mergeProps as l}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as n}from"@primereact/core/utils";var[g,e]=n();var r={as:"button"};var T=c({name:"AutoComplete.Trigger",defaultProps:r,setup(){return{autocomplete:e()}},render(t){let{props:m,ptmi:i,autocomplete:o}=t,s=l(o?.triggerProps,{className:o?.cx("trigger")},o?.ptm("trigger"),i("root"));return p.createElement(u,{instance:t,attrs:s,children:m.children})}});export{T as AutoCompleteTrigger,r as defaultTriggerProps};
