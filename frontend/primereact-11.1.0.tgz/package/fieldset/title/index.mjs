'use client';

import{Component as n,withComponent as d}from"@primereact/core/component";import{mergeProps as c}from"@primeuix/utils";import*as i from"react";import{createOptionalContext as m}from"@primereact/core/utils";var[a,o]=m();var r={as:"span"};var y=d({name:"Fieldset.Title",defaultProps:r,setup(){return{fieldset:o()}},render(e){let{props:s,ptmi:p,fieldset:t}=e,l=c({className:t?.cx("title")},t?.ptm("title"),p("root"));return i.createElement(n,{instance:e,attrs:l,children:s.children})}});export{y as FieldsetTitle,r as defaultTitleProps};
