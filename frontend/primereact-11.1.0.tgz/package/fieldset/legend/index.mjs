'use client';

import{Component as m,withComponent as l}from"@primereact/core/component";import{mergeProps as c}from"@primeuix/utils";import*as s from"react";import{createOptionalContext as d}from"@primereact/core/utils";var[a,o]=d();var r={as:"legend"};var C=l({name:"Fieldset.Legend",defaultProps:r,setup(){return{fieldset:o()}},render(e){let{props:i,ptmi:p,fieldset:t}=e,n=c({className:t?.cx("legend")},t?.ptm("legend"),p("root"));return s.createElement(m,{instance:e,attrs:n,children:i.children})}});export{C as FieldsetLegend,r as defaultLegendProps};
