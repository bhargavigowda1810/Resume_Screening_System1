'use client';

import{Component as l,withComponent as d}from"@primereact/core/component";import{mergeProps as g}from"@primeuix/utils";import*as i from"react";import{createOptionalContext as n}from"@primereact/core/utils";var[f,r]=n();var o={as:"button"};var C=d({name:"Fieldset.Trigger",defaultProps:o,setup(){return{fieldset:r()}},render(e){let{props:s,ptmi:p,fieldset:t}=e,m=g(t?.triggerProps,{className:t?.cx("trigger")},t?.ptm("trigger"),p("root"));return i.createElement(l,{instance:e,attrs:m,children:s.children})}});export{C as FieldsetTrigger,o as defaultTriggerProps};
