'use client';

import{Component as m,withComponent as l}from"@primereact/core/component";import{mergeProps as c}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as n}from"@primereact/core/utils";var[g,r]=n();var i={as:"span"};var y=l({name:"Paginator.Ellipsis",defaultProps:i,setup(){return{paginator:r()}},render(t){let{props:e,ptmi:a,paginator:o}=t,s=c({className:o?.cx("ellipsis")},o?.ptmi("ellipsis"),a("root"));return p.createElement(m,{instance:t,attrs:s,children:e.children})}});export{y as PaginatorEllipsis,i as defaultEllipsisProps};
