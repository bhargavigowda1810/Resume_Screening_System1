'use client';

import{Component as s,withComponent as c}from"@primereact/core/component";import{mergeProps as P}from"@primeuix/utils";import*as e from"react";import{createOptionalContext as m}from"@primereact/core/utils";var[f,r]=m();var n={as:"div"};var y=c({name:"Paginator.Content",defaultProps:n,setup(){return{paginator:r()}},render(t){let{props:a,ptmi:p,paginator:o}=t,i=P({className:o?.cx("content")},o?.ptmi("content"),p("root"));return e.createElement(s,{instance:t,attrs:i,children:a.children})}});export{y as PaginatorContent,n as defaultContentProps};
