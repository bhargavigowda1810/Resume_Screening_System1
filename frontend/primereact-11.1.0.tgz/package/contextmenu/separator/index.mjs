'use client';

import{Component as i,withComponent as u}from"@primereact/core/component";import{mergeProps as c}from"@primeuix/utils";import*as n from"react";import{createOptionalContext as s}from"@primereact/core/utils";var[C,o]=s();var r={as:"li"};var y=u({name:"ContextMenu.Separator",defaultProps:r,setup(){return{contextmenu:o()}},render(t){let{props:p,ptmi:a,contextmenu:e}=t,m=c(e?.separatorProps,{className:e?.cx("separator")},e?.ptm("separator"),a("root"));return n.createElement(i,{instance:t,attrs:m,children:p.children})}});export{y as ContextMenuSeparator,r as defaultSeparatorProps};
