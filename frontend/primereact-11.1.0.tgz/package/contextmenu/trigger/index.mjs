'use client';

import{Component as u,withComponent as c}from"@primereact/core/component";import{mergeProps as x}from"@primeuix/utils";import*as n from"react";import{createOptionalContext as s}from"@primereact/core/utils";var[a,r]=s();var o={as:"div"};var T=c({name:"ContextMenu.Trigger",defaultProps:o,setup(){return{contextmenu:r()}},render(t){let{props:p,ptmi:i,contextmenu:e}=t,m=x(e?.triggerProps,{className:e?.cx("trigger")},e?.ptm("trigger"),i("root"));return n.createElement(u,{instance:t,attrs:m,children:p.children})}});export{T as ContextMenuTrigger,o as defaultTriggerProps};
