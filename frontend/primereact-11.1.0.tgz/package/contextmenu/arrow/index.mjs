'use client';

import{Component as u,withComponent as c}from"@primereact/core/component";import{mergeProps as x}from"@primeuix/utils";import*as n from"react";import{createOptionalContext as i}from"@primereact/core/utils";var[C,e]=i();var r={as:"div"};var A=c({name:"ContextMenu.Arrow",defaultProps:r,setup(){return{contextmenu:e()}},render(t){let{props:p,ptmi:m,contextmenu:o}=t,s=x(o?.arrowProps,{className:o?.cx("arrow")},o?.ptm("arrow"),m("root"));return n.createElement(u,{instance:t,attrs:s,children:p.children})}});export{A as ContextMenuArrow,r as defaultArrowProps};
