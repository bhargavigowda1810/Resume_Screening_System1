'use client';

import{Component as i,withComponent as u}from"@primereact/core/component";import{mergeProps as c}from"@primeuix/utils";import*as r from"react";import{createOptionalContext as a}from"@primereact/core/utils";var[l,o]=a();var n={as:"li"};var L=u({name:"ContextMenu.Label",defaultProps:n,setup(){return{contextmenu:o()}},render(t){let{props:p,ptmi:m,contextmenu:e}=t,s=c(e?.labelProps,{className:e?.cx("label")},e?.ptm("label"),m("root"));return r.createElement(i,{instance:t,attrs:s,children:p.children})}});export{L as ContextMenuLabel,n as defaultLabelProps};
