'use client';

import{Component as s,withComponent as c}from"@primereact/core/component";import{mergeProps as C}from"@primeuix/utils";import*as a from"react";import{createOptionalContext as m}from"@primereact/core/utils";var[g,r]=m();var n={as:"div"};var d=c({name:"OrganizationChart.Content",defaultProps:n,setup(){return{organizationchart:r()}},render(t){let{props:e,ptmi:i,organizationchart:o}=t,p=C({className:o?.cx("content")},o?.ptm("content"),i("root"));return a.createElement(s,{instance:t,attrs:p,children:e.children})}});export{d as OrganizationChartContent,n as defaultContentProps};
