'use client';

import{Component as i,withComponent as u}from"@primereact/core/component";import{mergeProps as l}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as a}from"@primereact/core/utils";var[f,t]=a();var o={as:"li"};var g=u({name:"MeterGroup.Label",defaultProps:o,setup(){return{metergroup:t()}},render(e){let{props:m,ptmi:s,metergroup:r}=e,n=l(r?.labelProps,{className:r?.cx("label")},r?.ptm("label"),s("root"));return p.createElement(i,{instance:e,attrs:n,children:m.children})}});export{g as MeterGroupLabel,o as defaultLabelProps};
