'use client';

import{Component as u,withComponent as c}from"@primereact/core/component";import{mergeProps as x}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as i}from"@primereact/core/utils";var[f,r]=i();var o={as:"span"};var T=c({name:"MeterGroup.Text",defaultProps:o,setup(){return{metergroup:r()}},render(e){let{props:m,ptmi:s,metergroup:t}=e,n=x(t?.textProps,{className:t?.cx("text")},t?.ptm("text"),s("root"));return p.createElement(u,{instance:e,attrs:n,children:m.children})}});export{T as MeterGroupText,o as defaultTextProps};
