'use client';

import{Component as u,withComponent as c}from"@primereact/core/component";import{mergeProps as a}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as i}from"@primereact/core/utils";var[f,t]=i();var o={as:"div"};var C=c({name:"MeterGroup.Meters",defaultProps:o,setup(){return{metergroup:t()}},render(e){let{props:s,ptmi:m,metergroup:r}=e,n=a(r?.metersProps,{className:r?.cx("meters")},r?.ptm("meters"),m("root"));return p.createElement(u,{instance:e,attrs:n,children:s.children})}});export{C as MeterGroupMeters,o as defaultMetersProps};
