'use client';

import{Component as s,withComponent as n}from"@primereact/core/component";import{mergeProps as m}from"@primeuix/utils";import*as p from"react";import{createOptionalContext as e}from"@primereact/core/utils";var[S,t]=e(),[u,x]=e();var l={as:"div"};var V=n({name:"ScrollArea.Viewport",defaultProps:l,setup(){return{scrollarea:t()}},render(r){let{props:a,ptmi:i,scrollarea:o}=r,c=m(o?.viewportProps,{className:o?.cx("viewport")},o?.ptm("viewport"),i("root"));return p.createElement(s,{instance:r,attrs:c,children:a.children})}});export{V as ScrollAreaViewport,l as defaultViewportProps};
