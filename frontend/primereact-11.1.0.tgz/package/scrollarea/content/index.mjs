'use client';

import{Component as s,withComponent as i}from"@primereact/core/component";import{mergeProps as m}from"@primeuix/utils";import*as l from"react";import{createOptionalContext as t}from"@primereact/core/utils";var[S,e]=t(),[C,u]=t();var n={as:"div"};var y=i({name:"ScrollArea.Content",defaultProps:n,setup(){return{scrollarea:e()}},render(r){let{props:a,ptmi:c,scrollarea:o}=r,p=m(o?.contentProps,{className:o?.cx("content")},o?.ptm("content"),c("root"));return l.createElement(s,{instance:r,attrs:p,children:a.children})}});export{y as ScrollAreaContent,n as defaultContentProps};
