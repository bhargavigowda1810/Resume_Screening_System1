'use client';

import{Component as i,withComponent as c}from"@primereact/core/component";import{mergeProps as f}from"@primeuix/utils";import*as n from"react";import{createOptionalContext as m}from"@primereact/core/utils";var[C,e]=m();var r={as:"div"};var v=c({name:"Tabs.Content",defaultProps:r,setup(){return{tabs:e()}},render(o){let{props:s,ptmi:p,tabs:t}=o,a=f({className:t?.cx("content")},t?.contentProps,t?.ptm("content"),p("root"));return n.createElement(i,{instance:o,attrs:a,children:s.children,ref:t?.contentRef})}});export{v as TabsContent,r as defaultContentProps};
