'use client';

import{Component as n,withComponent as c}from"@primereact/core/component";import{mergeProps as b}from"@primeuix/utils";import*as e from"react";import{createOptionalContext as m}from"@primereact/core/utils";var[l,r]=m();var s={as:"div"};var C=c({name:"Tabs.List",defaultProps:s,setup(){return{tabs:r()}},render(t){let{props:p,ptmi:i,tabs:o}=t,a=b({className:o?.cx("list")},o?.scrollStateAttrs,o?.ptm("list"),i("root"));return e.createElement(n,{instance:t,attrs:a,children:p.children})}});export{C as TabsList,s as defaultListProps};
